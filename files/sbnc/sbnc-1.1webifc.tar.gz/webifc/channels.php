<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');
sbnc_guard();

if (isset($_REQUEST['part'])) {
  sbnc_command('raw PART ' . $_GET['part']);
  printf('<fieldset><legend>%s</legend>'.$lang_channels['part'].'.</fieldset><br />',$lang_channels['partlegend'],htmlentities($_GET['part']));
}

if (isset($_REQUEST['join'])) {
  if (isset($_REQUEST['key']) && strlen($_REQUEST['key']) > 0) {
    sbnc_command('raw JOIN '.$_REQUEST['join'].' '.$_REQUEST['key']);
  } else {
    sbnc_command('raw JOIN ' . $_REQUEST['join']);
  }
  printf('<fieldset><legend>%s</legend>'.$lang_channels['join'].'.</fieldset><br />',$lang_channels['joinlegend'],htmlentities($_GET['join']));
}


function cmp ($a, $b) {
   return strcmp(strtolower($a), strtolower($b));
}

if (isset($_REQUEST['info'])) {
  printf('<fieldset><legend>'.$lang_channels['channellegend'].'</legend>',htmlentities($_GET['info']));
  printf('<table width="100%%">');
  printf('<tr><td width="20%%"><b>%s</b></td><td>%s</td></tr>',$lang_channels['channel'],htmlentities($_GET['info']));
  printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_channels['chanmodes'],htmlentities(sbnc_command('chanmode ' . $_GET['info'])));
  printf('<tr><td valign="top"><b>%s</b></td><td>%s</td></tr>',$lang_channels['topic'],htmlentities(sbnc_command('topic ' . $_GET['info'])));
  printf('<tr><td valign="top"><b>%s</b></td><td>',$lang_channels['users']);
  $users = split(" ",htmlentities(sbnc_command('chanlist ' . $_GET['info'])));
  usort($users, "cmp");
  foreach ($users as $user) {
    echo $user.'</br>';
  }
  echo '</table>';
  echo '</fieldset>';
  echo '<br />';
}

printf('<fieldset><legend>%s</legend>',$lang_channels['channellegend']);

if (sbnc_command('value hasserver')) {

printf('
<form>
<input type="hidden" name="p" value="channels">
<label>%s</label>
<input name="join">
<label>%s</label>
<input style="width: 70px;" name="key">
<input type="submit" value="%s">
</form>', $lang_channels['joinchannel'], $lang_channels['key'], $lang_channels['joinbutton']);

printf('<table border="0" width="60%%"><tr><td width="40%%">%s</td><td width="10%%">%s</td><td width="30%%">%s</td><td>%s</td></tr>',$lang_channels['channel'],$lang_channels['users'],$lang_channels['chanmodes'],$lang_channels['command']);

$chans = explode(' ', sbnc_command('channels'));
usort($chans, "cmp");
$total = 0;
foreach ($chans as $chan) {
  if ($chan != "") {
    printf('<tr><td><a href="index.php?p=channels&info=%s">%s</a></td><td>%s</td><td>%s</td><td><form>',urlencode($chan),$chan,htmlentities(sbnc_command('usercount ' . $chan)),htmlentities(sbnc_command('chanmode ' . $chan)));
	printf('<input type="button" value="%s" onClick="parent.location=\'index.php?p=channels&part=%s\'">',$lang_channels['partbutton'],urlencode($chan));
	printf('</form>
	</td></tr>');
    $total++;
  }
}

printf('</table><br />');
printf('%s '.$total,$lang_channels['totalchannels']);
} else {
  printf('%s',$lang_channels['notconnected']);
}
printf('</fieldset>');

?>