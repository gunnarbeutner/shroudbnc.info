<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

class SBNC {
	var $socket, $num, $user, $pass;

	function SBNC($host, $port, $user, $pass) {
		$this->num = 0;
		$this->user = $user;
		$this->pass = $pass;
		$this->socket = @fsockopen($host, $port, $errno, $errstr, 30);
		if (!$this->socket) {
		    /* echo "<b>$errstr</b>"; */
		}
		
	}

	function Destroy() {
		fclose($this->socket);
	}

	function Command($command) {
		$this->num++;
		fputs($this->socket, $this->num . ' ' . $this->user . ' ' . $this->pass . ' ' . $command . "\n");
		$line = str_replace("\r", "", str_replace("\n", "", fgets($this->socket)));
		$arr = explode(' ', $line, 2);

		if ($arr[0] == $this->num) {
			return $arr[1];
		} else {
			return "105";
		}
	}
	function IsValid() {
	    return ($this->socket != FALSE);
	}
	function Relogin($user, $pass) {
	    $this->user = $user;
	    $this->pass = $pass;
	}
}

?>