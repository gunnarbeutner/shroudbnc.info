<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sbnc.php');
include('config.php');
@session_start();

function sbnc_checklogin() {
  include('config.php');
  if (count($connections) == 1) {
    foreach ($connections as $n => $c) {
	$_SESSION['sbncconn'] = $n;
    }    
  }
}

function sbnc_conn($user, $pass) {
  global $conn;
  include('config.php');
  foreach ($connections as $n => $cc) {
    if ($n == $_SESSION['sbncconn']) {
	$c = explode(" ", $cc);
    }
  }      
  $conn = new SBNC($c[0], $c[1], $user, $pass);
  if (!$conn->IsValid())
    return false;
    
  return sbnc_command('null') == '1' ? (sbnc_command('value lock') == '1' ? false : true) : false;
}

function sbnc_command($command) {
  global $conn;

  return $conn->Command($command);
}

function sbnc_guard() {
  global $account;

  $account = "";

  if (!isset($_SESSION['sbncconn']) || !isset($_SESSION['sbncusername']) || !isset($_SESSION['sbncpass']) || !sbnc_login($_SESSION['sbncusername'], $_SESSION['sbncpass'])) {
    header('Location: login.php');
    exit;
  }

  $account = $_SESSION['sbncusername'];
}
function sbnc_login($user, $password) {
    $conn = sbnc_conn($user, $password);
    if ($conn) {
	$_SESSION['sbncusername'] = $user;
	$_SESSION['sbncpass'] = $password;
	
	return true;
    } else {
	return false;
    }
}
				    

function sbnc_account() {
    if (isset($_SESSION['sbncusername'])) {
	return $_SESSION['sbncusername'];
    } else {
	return "";
    }
}

function sbnc_guardadmin() {
    sbnc_command('value admin') or die('Access denied.');
}

function sbnc_guardvirtual() {
    sbnc_command('visadmin') or die('Access denied.');
}

function sbnc_relogin($user, $pass) {
    global $conn;
    $conn->Relogin($user, $pass);
}
?>