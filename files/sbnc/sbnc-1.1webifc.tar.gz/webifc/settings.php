<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
$nick = sbnc_command('nick');
if (isset($_REQUEST['name']) && isset($_REQUEST['value'])) {
  $name = $_REQUEST['name'];
  $value = $_REQUEST['value'];
  if (sbnc_command("tag lock ".$name)) { return; }
  switch ($name) {
    case 'server':
      sbnc_command('set server ' . $value);
      break;
    case 'port':
      sbnc_command('set port ' . $value);
      break;
    case 'realname':
      sbnc_command('set realname ' . $value);
      break;
    case 'nick':
      sbnc_command('simul NICK ' . $value);
      $nick = $value;
      break;
    case 'awaynick':
      sbnc_command('set awaynick ' . $value);
      break;
    case 'away':
      sbnc_command('set away ' . $value);
      break;
    case 'vhost':
      sbnc_command('set vhost ' . $value);
      break;
    case 'awaymessage':
      sbnc_command('set awaymessage ' . $value);
      break;
    case 'password':
      if(sbnc_command('set password ' . $value) == 1) {
        $_SESSION['sbncpass'] = $value;
	sbnc_relogin($_SESSION['sbncusername'],$_SESSION['sbncpass']);
      }
      break;
  }
  printf('<fieldset><legend>%s</legend>%s', $lang_settings['settings'], $lang_settings['settingschanged']);
  if ($name == "realname") { echo $lang_settings['settingsonlyreconnect']; }
  echo '</fieldset><br />';
}

if (isset($_GET['jump'])) {
  sbnc_command('jump');

  printf('<fieldset><legend>%s</legend>',$lang_settings['jump']);
  printf('%s',$lang_settings['reconnect']);
  printf('</fieldset><br />');

}


printf('<fieldset><legend>%s</legend>',$lang_settings['settings']);
printf('<table><tr><td align="right"><b>%s</b></td><td align="center"><b>%s</b></td><td align="center"><b>%s</b></td></tr>',$lang_settings['name'],$lang_settings['value'],$lang_settings['commit']);

  $awaymsgplugin = sbnc_command('hasplugin awaymsg');

  $options = array(
	"Password" => "password",
	"Server" => "server",
	"Port" => "port",
	"Nick" => "nick",
	"Realname" => "realname",
	"Away-Nick" => "awaynick",
	"Away-Reason" => "away",
	"Away-message" => "awaymessage",
	);
	foreach ($options as $option => $bnc) {
	  if (($bnc != "awaymessage" && sbnc_command("lockedsetting ".$bnc) == 0) || ($bnc == 'awaymessage' && $awaymsgplugin && sbnc_command("lockedsetting awaymessage") == 0)) { 
	    echo '
		<tr><td valign="top" align="right">'.$lang_settings[$option].'</td><td>
		<form method="post" action="index.php">
		<input type="hidden" name="p" value="settings" />
		<input type="hidden" name="name" value="'.$bnc.'" />
		<input ';
	    if ($bnc == "password") { echo 'type="password" '; }
	    echo 'size="40" name="value" value="';
    	    if ($bnc == "nick") { echo $nick; } 
    	    else if ($bnc == "awaymessage") { echo stripslashes(sbnc_command('tag awaymessage')); }
    	    else if ($bnc != "password") { echo stripslashes(sbnc_command('value '.$bnc)); }
	    echo '" />';
	    printf('
		</td><td valign="top">
		<input type="submit" value="%s">
		</td></form></tr>
		',$lang_settings['set']);
	  }
	}
	if (sbnc_command('lockedsetting vhost') != 1) {
	    if (sbnc_command('hasplugin vhost')) {
		$vhosts = explode("\005", sbnc_command('vhosts'));
		$cvhost = sbnc_command('value vhost');
		echo '
		    <tr><td valign="top" align="right">'.$lang_settings['Vhost'].'</td><td>
	    	    <form method="post" action="index.php">
	    	    <input type="hidden" name="p" value="settings" />
		    <input type="hidden" name="name" value="vhost">
		    <select style="width:100%;" name="value">';
		foreach ($vhosts as $vhost) {
		    $vh = explode(" ", $vhost);
		    if ($vh["2"] <= $vh["1"]) {
			echo '<option value="'.$vh["0"].'" ';
			if ($vh["0"] == $cvhost || $vh["3"] == $cvhost) { echo 'selected'; }
			printf('>'.$vh["3"].' (%s)</option>', $lang_settings['full']);
		    } else {
			echo '<option value="'.$vh["0"].'" ';
			if ($vh["0"] == $cvhost || $vh["3"] == $cvhost) { echo 'selected'; }
			printf('>'.$vh["3"].' (%s)</option>', $lang_settings['notfull']);
		    }
	        }
		printf('</select></td><td valign="top">
		    <input type="submit" value="%s">
		    </td></form></tr>
		    ', $lang_settings['set']);
	    } else {
		printf('
		    <tr><td valign="top" align="right">'.$lang_settings['Vhost'].'</td><td>
		    <form method="post" action="index.php">
		    <input type="hidden" name="p" value="settings" />
		    <input type="hidden" name="name" value="vhost">
		    <input size="40" name="value" /></td><td valign="top"><input type="submit" value="%s">
		    </td></form></tr>', $lang_settings['set']);
	    }
	}
printf('</table><br><form><input TYPE="button" onClick="parent.location=\'index.php?p=settings&jump\'" value="%s"></form></fieldset>',$lang_settings['jump']);