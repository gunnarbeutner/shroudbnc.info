<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
sbnc_guardadmin();

printf('<fieldset><legend>%s</legend>', $lang_mainlog['mainloglegend']);

if (isset($_GET['erase'])) {
  sbnc_command('erasemainlog');

  printf('%s', $lang_mainlog['logerased']);
  return;
}

$lines = explode("\005", sbnc_command('mainlog'));

foreach ($lines as $line) {
  echo $line . "<br>";
}

printf('
<form>
<input TYPE="button" onClick="parent.location=\'index.php?p=mainlog&erase\'" value="%s">
</form>
</fieldset>
',$lang_mainlog['erasemainlogbutton']);

?>