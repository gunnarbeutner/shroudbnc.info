<?

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "send") {
    if ($_REQUEST['message'] != "") {
	if (strlen($_REQUEST['email']) < 2) { $email = "n/a"; } 
	else { $email = $_REQUEST['email']; }
	$message = " (".$lang_contact['email']. ': ' .$email."): ".$_REQUEST['message'];
	sbnc_command('sendmessage ' . str_replace("\r\n", "\005", $message));
	
	printf('<fieldset><legend>%s</legend>',$lang_contact['messagesendlegend']);
	printf('%s %s',$lang_contact['messagesend'],$_REQUEST['message']);
	printf('<br /><br />%s</fieldset><br />',$lang_contact['notelogcheck']);
		
    }
}

printf('<fieldset><legend>%s</legend><br />',$lang_contact['contactlegend']);
printf('	
	<form method="POST" action="index.php">
	<input type="hidden" name="p" value="contact">
	<input type="hidden" name="do" value="send">
	<table>
	<tr><td>%s</td><td><input name="email"></td></tr>
	<tr><td valign="top" align="right">%s</td><td><textarea name="message" cols="50" rows="10"></textarea>
	<tr><td></td><td align="right"><input type="submit" value="%s" name="send"></td></tr>
	</table>
	</form>
	%s',$lang_contact['ownemail'],$lang_contact['message'],$lang_contact['send'],$lang_contact['optional']);
printf('</fieldset>');

?>