<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
sbnc_guardadmin();
if (isset($_REQUEST['notice'])) {
	printf(sbnc_command('global '.$_REQUEST['notice']));;
	printf('<fieldset><legend>%s</legend>',$lang_global['globalnoticelegend']);
	printf('%s %s', $lang_global['successfullysend'], $_REQUEST['notice']);
	printf('</fieldset><br />');
}
if (isset($_REQUEST['die'])) {
 if (isset($_REQUEST['dieconfirmation'])) {
   printf('
    <fieldset><legend>%s</legend>
	%s
	</fieldset><br />
	', $lang_global['bncdisconnectedlegend'], $lang_global['bouncerkilled']);
   sbnc_command('tcl die');
 } else {
   printf('
	<fieldset><legend>%s</legend>
	<form method="post" action="index.php">
		<input type="hidden" name="p" value="global" />
		<input type="hidden" name="die">
		<input type="hidden" name="dieconfirmation"></input>
		<label><b>%s</b></label><br /><br />
		<input type="submit" value="%s"></input>
	</form></fieldset><br />', $lang_global['dielegend'], $lang_global['dieconfirmation'], $lang_global['die']);
  }
}
if (isset($_REQUEST['tclrehash'])) {
  printf('<fieldset><legend>%s</legend>
				%s
			</fieldset><br />', $lang_global['TCLlegend'], $lang_global['TCLsuccessfullrehash']);
	sbnc_command('tcl rehash');
}
printf('
<fieldset><legend>%s</legend>
  <fieldset><legend>%s</legend>
    <form method="post" action="index.php">
	  <input type="hidden" name="p" value="global" />
	  <input type="text" name="notice"></input>
	  <input type="submit" value="%s"></input>
	</form>
   </fieldset>
   <br />
   <fieldset><legend>%s</legend>
    <table><tr><td>
     <form>
	  <input style="width:90px;" type="button" onClick="parent.location=\'index.php?p=global&die\'" value="%s">
     </form>
</td><td>
	 <form>
	  <input style="width:90px;" type="button" onClick="parent.location=\'index.php?p=global&tclrehash\'" value="%s">
	 </form>
	 </td></tr></table>
   </fieldset>
</fieldset>',$lang_global['globallegend'], $lang_global['globalnoticelegend'], $lang_global['send'], $lang_global['administration'], $lang_global['die'], $lang_global['tclrehash']);

?>  
