<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');
sbnc_guard();

printf('<fieldset><legend>%s</legend>',$lang_info['accountinfo']);
printf('<table width="100%%">');
printf('<tr><td width="20%%"><b>%s</b></td><td>%s</td></tr>',$lang_info['username'],$_SESSION['sbncusername']);
printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_info['currentnick'],htmlentities(sbnc_command('nick')));
printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_info['uptime'],htmlentities(sbnc_command('uptimehr')));

$traffic = explode(' ', sbnc_command('traffic'));
$total = 0;

foreach ($traffic as $k => $v) {
	$total += $traffic[$k];
	$traffic[$k] = round($v / 1024 / 1024, 2) . ' MBytes';
}

$client = sbnc_command('value client');
$server = sbnc_command('value realserver');

printf('<tr><td></td></tr>');

if (sbnc_command('value hasserver')) {
	printf('<tr><td><b>%s</b></td><td>%s (%s)</td></tr>',$lang_info['server'],htmlentities($server),htmlentities(sbnc_command('network')));
} else {
	printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_info['server'],$lang_info['notconnected']);
}
if ($client == '') { $client = $lang_info['none']; }
else { $client = htmlentities($client); }
printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_info['client'],$client);
if (sbnc_command('value admin')) {
    $level = $lang_info['administrator'];
} else if (sbnc_command('visadmin ' . $account)) {
    $level = $lang_info['virtualadministrator'];
} else {
    $level = $lang_info['user'];
}
		    
printf('<tr><td><b>%s</b></td><td>%s</td></tr>',$lang_info['level'], $level);
printf('</table></fieldset>');

printf('<br />');
printf('<fieldset><legend>%s</legend>',$lang_info['traffic']);
printf('<table border="0" width="40%%">');
printf('<tr><td width="5%%"></td><td width="10%%"><b>%s</b></td><td width="10%%"><b>%s</b></td></tr>',$lang_info['in'],$lang_info['out']);
printf('<tr><td><b>%s</b></td><td>%s</td><td>%s</td></tr>',$lang_info['server'],$traffic[0], $traffic[1]);
printf('<tr><td><b>%s</b></td><td>%s</td><td>%s</td></tr>',$lang_info['client'],$traffic[2], $traffic[3]);
printf('<tr><td></td><td></td></tr>');
printf('<tr><td><b>%s</b><td colspan="2" align="center">%s Mbytes</td></tr>',$lang_info['totaltraffic'], round($total / 1024. / 1024., 2));
printf('</table></fieldset>');

?>