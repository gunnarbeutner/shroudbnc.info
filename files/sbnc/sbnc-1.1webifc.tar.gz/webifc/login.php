<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

@session_start();
include_once('sec.php');
sbnc_checklogin();

if (isset($Back)) {
    session_destroy();
    Header('Location: login.php');
}

if (isset($_REQUEST['connection'])) {
    $_SESSION['sbncconn'] = $_REQUEST['connection'];
}

if (!isset($_SESSION['sbncconn'])) {
    if (count($connections) == 1) {
	foreach ($connections as $n => $c) {
	    $_SESSION['sbncconn'] = $n;
	}
    } else {
	include_once($defaultlanguagefile);
	printf('
	    <html>
	        <head>
		    <title>%s</title>
		</head>
		<link rel="stylesheet" href="%s" type="text/css">
		<body>
	',$lang_index['htmltitle'],$ifacetheme);
	printf('
	    <div class="heading">%s</div>
	    ',$lang_index['title']);
	printf('<br /><fieldset><legend>%s</legend>',$lang_index['login']);
	printf('<form method="POST" action="login.php"><select name="connection">');
	foreach ($connections as $name => $connection) {
	    $c = explode(" ", $connection);
	    echo '<option value="'.$name.'">'.$name.' ('.$c[0].':'.$c[1].')</option>';
	}
	printf('</select><br /><br /><input type="submit" name="%s" value="Select"></form></body></html>', $lang_index['select']);
	printf('</form></body></html>');
	return;
    }
}

if (isset($_REQUEST['user']) && isset($_REQUEST['pass'])) {
    include_once($defaultlanguagefile);
    $ret = sbnc_login($_REQUEST['user'], $_REQUEST['pass']);
    if ($ret == true) { echo '<META HTTP-EQUIV=Refresh CONTENT="1; URL=index.php">'; }
    echo '<link rel="stylesheet" href="' . $ifacetheme . '" type="text/css">';
    echo '
        <div class="heading">shroudBNC Webinterface</div>
        ';
    echo '<br />';
    if ($ret == true) {
	echo '<fieldset> <legend> Login </legend> You were successfully logged in. </fieldset>';
    } else {
	printf('<fieldset><legend> Login </legend> Error: Wrong Username / Password.<br /><form><input type="submit" value="Back"></form> </fieldset>');
    }
    return;
}
?>
				    
<html>
    <head>
        <title>shroudBNC Webinterface</title>
    </head>
    <link rel="stylesheet" href="<?php echo($ifacetheme); ?>" type="text/css">
<body>
    <div class="heading">shroudBNC Webinterface</div>
    <br />
    <fieldset><legend>Login</legend>
    <table>
    <form method="POST">
	<tr><td><label>Username: </label></td><td><input name="user" /></td></tr>
	<tr><td><label> Password: </label></td><td><input type="password"  name="pass" /></td></tr>
	<tr><td>&nbsp;</td><td align="right">
	<input style="float:right; margin-left: 4pt;" type="submit" value="Login">
<?php if (count($connections) > 1) { echo '<input type="submit" value="Back" name="Back"> '; } ?>
    </td></tr></table>
    </form>
    </fieldset>
</body>
</html>