<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

@session_start();
include_once('sec.php');
error_reporting(E_ALL);
sbnc_checklogin();


if (!isset($_REQUEST['p']) || $_REQUEST['p'] != "login") {
    sbnc_guard();
    $lang = sbnc_command('tag lang');
    $file = 'lang/lang-'.$lang.'.php';
    if (is_file($file)) { include_once($file); }
    else { include_once($defaultlanguagefile); }
}
if (isset($_REQUEST['p']) && $_REQUEST['p'] == "logout") {
    session_destroy();
    printf('
	<html>
	    <head>
		<title>%s</title>
	    </head>
	<link rel="stylesheet" href="%s" type="text/css">
	<body>
	',$lang_index['htmltitle'],$ifacetheme);
    printf('
	    <div class="heading">%s</div>
	    ',$lang_index['title']);
    printf('<br /><fieldset><legend>%s</legend>%s</fieldset>',$lang_index['logoutlegend'],$lang_index['logoutlink']);
    printf('</body></html>');
    return;
}

printf('
<html>
    <head>
	<title>%s</title>
    </head>
    <link rel="stylesheet" href="%s" type="text/css">
    <body>
	<div class="heading">%s</div>
		    <div class="buttonscontainer">
			    <div class="menutitle">%s</div>
			    <div class="buttons">
			    ',$lang_index['htmltitle'],$ifacetheme,$lang_index['title'],$lang_index['user']);

			$usermenu = array(
			    "info" => "0",
			    "settings" => "0",
			    "channels" => "0",
			    "log" => "0",
			    "hosts" => "0",
			    "qauth" => "qauth",
			    "language" => "0",
			    "contact" => "contact",
			    "logout" => "0"
			    );
			foreach ($usermenu as $menupoint => $modul) {
			    if ($modul == "0" || sbnc_command('hasplugin '.$modul)) {
				if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '<active>'; }
				printf("<a href='?p=%s'>%s</a>",$menupoint, $lang_index[$menupoint]);
				if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '</active>'; }
			    }
			}
		if (sbnc_command('visadmin')) {
		    printf('</div><div class="menutitle">%s</div><div class="buttons">',$lang_index['vadmin']);
		    $vadminmenu = "vlist";
		    $vadminmenu2 = split(" ", $vadminmenu);
		    foreach ($vadminmenu2 as $menupoint) {
			if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '<active>'; }
			printf('<a href="?p=%s">%s</a>
				',$menupoint, $lang_index[$menupoint]);
			if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '</active>'; }
		    }
		}
		if (sbnc_command('hasplugin virtual') && sbnc_command('value admin')) {
		    printf('</div><div class="menutitle">%s</div><div class="buttons">',$lang_index['vadmin']);
		    $vadminmenu = "vgroups";
		    $vadminmenu2 = split(" ", $vadminmenu);
		    foreach ($vadminmenu2 as $menupoint) {
			if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '<active>'; }
			printf('<a href="?p=%s">%s</a>
				',$menupoint, $lang_index[$menupoint]);
			if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '</active>'; }
		    }
		}
		if (sbnc_command('value admin')) {
		    printf('</div><div class="menutitle">%s</div><div class="buttons">',$lang_index['admin']);
		    $adminmenu = array(
			"global" => "0",
			"userlist" => "0",
			"mainlog" => "0"
			);
		    foreach ($adminmenu as $menupoint => $modul) {
			if ($modul == "0" || sbnc_command('hasplugin '.$modul)) {
			    if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '<active>'; }
				printf('<a href="?p=%s">%s</a>
				    ',$menupoint, $lang_index[$menupoint]);
			    if (isset($_REQUEST['p']) && $_REQUEST['p'] == $menupoint) { echo '</active>'; }
			}
		    }
		}
		printf('</div></div>');
	    printf('<div class="main">');
	    if (isset($_REQUEST['p'])) {
	        $file = $_REQUEST['p'].".php";
	        if (!is_file($file)) {
		    include('info.php');
		} else {
		    include $file;
	        }
	    } else {
		include('info.php');
	    }
	    printf('</div></body></html>');
?>
