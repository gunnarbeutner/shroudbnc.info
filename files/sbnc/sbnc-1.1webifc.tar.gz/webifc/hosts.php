<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');
sbnc_guard();

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "remove") {
    sbnc_command('delhost '.$_REQUEST['host']);
    printf('<fieldset><legend>%s</legend>',$lang_hosts['hosts']);
    printf('%s</fieldset><br />', $lang_hosts['done']);
}

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "add") {
    if (isset($_REQUEST['host']) && $_REQUEST['host'] != "") {
	sbnc_command('addhost '.$_REQUEST['host']);
	printf('<fieldset><legend>%s</legend>',$lang_hosts['hosts']);
	printf('%s</fieldset><br />', $lang_hosts['done']);
    }
}

printf('<fieldset><legend>%s</legend>',$lang_hosts['hosts']);
printf('<form action="index.php" method="POST">
	<input type="hidden" name="p" value="hosts">
	<input type="hidden" name="do" value="add">
	<input name="host">
	<input type="submit" value="%s" name="add">
	</form>', $lang_hosts['add']);
printf('<table width="100%%">');
printf('<tr><td width="30%%">%s</td><td align="left">%s</td></tr>',$lang_hosts['hosts'], $lang_hosts['action']);
$hosts = sbnc_command('hosts');
$hosts = explode(" ", $hosts);
foreach ($hosts as $host) {
    if ($host != "") {
	printf('<tr><td>'.$host.'</td><td><form action="index.php" method="POST">
	    <input type="hidden" name="p" value="hosts">
	    <input type="hidden" name="host" value="'.$host.'">
	    <input type="hidden" name="do" value="remove">
	    <input type="submit" value="%s" name="remove"></form>',$lang_hosts['remove']);
    }
}