<?php

	/*****************************************************
	 *	German language file for webinterface		          *
	 ******************************************************/

	 // index.php
	 $lang_index = array(
 						"htmltitle" => "shroudBNC Webinterface",
						"title" => "shroudBNC Webinterface",
						"logoutlegend" => "Ausloggen",
						"logoutlink" => "Du bist nun ausgeloggt. Klicke <a href='login.php'>hier</a> um dich erneut einzuloggen.",
						"user" => "Benutzer",
						"info" => "Infos",
						"settings" => "Einstellungen",
						"channels" => "Kan�le",
						"log" => "Log",
						"qauth" => "Qauth",
						"contact" => "Kontakt",
						"logout" => "Ausloggen",
						"vadmin" => "Vadmin",
						"vlist" => "Nutzerliste",
						"hosts" => "Hosts",
						"vgroups" => "Vgroups",
						"admin" => "Administrator",
						"global" => "Global",
						"userlist" => "Nutzerliste",
						"mainlog" => "Serverlog",
						"language" => "Sprache",
						"login" => "Login",
						"select" => "Select"
					);
						
	 
	 // info.php
	$lang_info = array(
						"accountinfo" => "Informationen �ber deinen Account",
						"username" => "Benutzername",
						"currentnick" => "Aktueller Nickname",
						"uptime" => "Onlinezeit",
						"client" => "Client",
						"none" => "Kein",
						"server" => "Server",
						"notconnected" => "Nicht verbunden",
						"traffic" => "Traffic",
						"in" => "In",
						"out" => "Out",
						"totaltraffic" => "Absoluter Traffic"
,
						"level" => "Level",
						"user" => "Benutzer",       
			                        "virtualadministrator" => "Virtueller Administrator",
						"administrator" => "Administrator"
					);
	
	// settings.php
	$lang_settings = array(
						"jump" => "Jump",
						"reconnect" => "Verbinde...",
						"settings" => "Einstellungen",
						"name" => "Name",
						"value" => "Wert",
						"commit" => "Best�tige",
						"Password" => "Passwort",
						"Server" => "Server",
						"Port" => "Port",
						"Nick" => "Nick",
						"Realname" => "Wirklicher Name",
						"Away-Nick" => "Away-Name",
						"Away-Reason" => "Away-Grund",
						"Away-message" => "Away-Nachricht",
						"Vhost" => "Vhost",
						"set" => "Setze",
						"settingschanged" => "Die Einstellungen wurden uebernommen.",
						"settingsonlyreconnect" => " (Damit diese Einstellung uebernommen wird, muss geJUMP'd werden.)",
						"full" => "voll",
						"notfull" => "nicht voll"
						);
	
	// channels.php
	$lang_channels = array(
						"partlegend" => "Verlasse Kanal",
						"part" => "Kanal %s verlassen", // %s == channel name
						"joinlegend" => "Betrete Kanal",
						"join" => "Kanal %s betreten", // %s == channel name
						"channel" => "Kanal",
						"chanmodes" => "Kanalmodes",
						"topic" => "Thema",
						"users" => "Nutzer",
						"channellegend" => "Kan�le",
						"command" => "Kommandos",
						"totalchannels" => "Kan�le insgesamt: ",
						"notconnected" => "Du bist nicht verbunden.",
						"partbutton" => "Verlasse",	
						"joinchannel" => "Betrete Kanal: ",
						"joinbutton" => "Betrete",
						"key" => "Schluessel:"			
					);
	
	// log.php
	$lang_log = array(
						"logerase" => "Log wurde gel�scht.",
						"erasebutton" => "L�sche log",
						"loglegend" => "Privates log"
,
						"logempty" => "Das Log ist leer."
					);
					
	// qauth.php 
	$lang_qauth = array(
						"qauthlegend" => "Qauth",
						"done" => "erledigt.",
						"note" => "Note: </b>Dein Passwort und dein Benutzername werden unverschl�sselt gespeichert. Benutze diese Funktion nur, wenn du damit einverstanden bist und dich zum QuakeNet verbindest!",
						"username" => "Benutzername:",
						"password" => "Passwort:",
						"umodex" => "umode x:",
						"set" => "Setze"
					);
					
	// contact.php
	$lang_contact = array(
						"email" => "email-adresse",
						"messagesendlegend" => "Nachrichtig gesendet.",
						"messagesend" => "Die folgende Nachricht wurde gesendet: ",
						"contactlegend" => "Kontakt",
						"ownemail" => "Eigene email-adresse:*",
						"message" => "Nachricht: ",
						"send" => "Sende",
						"notelogcheck" => "�berpr�fe dein log regelm��ig (oder dein Emailaccount, falls angegeben).",
						"optional" => "* optional"
					);

	// vgroups.php
	$lang_vgroups = array(
						"cantunadmin" => "Du kannst deinen eigenen Administratorstatus nicht l�schen.",
						"virtualadministratorlegend" => "Virtueller Administrator",
						"cantchangeuser" => "Benutzer konnte nicht ver�ndert werden.",
						"nolongervadmin" => "Benutzer %s ist nicht l�nger virtueller Administrator.",
						"nowvadmin" => 	"Benutzer %s ist von nun an virtueller Administrator.",
						"usersofgroup" => "Nutzer der Gruppe: %s", // %s is groupname
						"user" => "Benutzer",
						"level" => "Level",
						"virtualadministrator" => "Virtueller Administrator",
						"newlimit" => "Neues limit der Gruppe %s wurde auf %s gesetzt.",  // first %s is groupname, second %s is the new limit
						"setnewlimitlegend" => "Setze limit der Gruppe %s", // %s is groupname
						"setlimitlegend" => "Setze neues limit",
						"set" => "Setze",
						"creategrouplegend" => "Erstelle Gruppe",
						"groupcreated" => "Gruppe %s wurde erstellt. Zus�tzlich wurde ein Nutzer mit gleichem Name und Passwort %s erstellt.",
						"desc" => "Beschreibung",
						"name" => "Name",
						"limit" => "Limit",
						"createbutton" => "Erstelle",
						"deletegrouplegend" => "L�sche Gruppe",
						"groupnotdeleted" => "Gruppe konnte nicht gel�scht werden: ",
						"groupwasdeleted" => "Gruppe %s wurde gel�scht.", // %s is groupname
						"deletegrouplegend" => "L�sche Gruppe %s", // %s is groupname
						"deleteconfirmation" => "M�chte du die Gruppe %s wirklich l�schen?", // %s is groupname
						"delete" => "L�sche",
						"group" => "Gruppe",
						"groups" => "Gruppen",
						"users" => "Nutzer",
						"action" => "Aktion",
						"setlimit" => "Setze limit",
						"do" => "do",
						"value" => "Wert",
						"nogroups" => "Es gibt keine Gruppen",
						"creategroupbutton" => "Erstelle Gruppe",
						"failedcreate" => "Die Gruppe konnte nicht erstellt werden: ",			
						"failedlimitlegend" => "Neues limit nicht gesetzt.",
						"newlimitfailed" => "Konnte limit f�r die Gruppe %s nicht setzen." // %s is groupname
					);
					
	// global.php
	$lang_global = array(
						"globalnoticelegend" => "Globale Nachricht",
						"successfullysend" => "Erfolgreich gesendet: ",
						"bncdisconnectedlegend" => "Bouncer beenden",
						"bouncerkilled" => "Der Bouncer wurde beendet.",
						"dielegend" => "Beenden",
						"dieconfirmation" => "M�chtest du den Bouncer wirklich beenden",
						"die" => "Beenden",
						"TCLsuccessfullrehash" => "TCL wurde erfolgreich rehashed.",
						"TCLlegend" => "TCL",
						"globallegend" => "Global",
						"globalnoticelegend" => "Globale Nachricht",
						"send" => "Gesendet",
						"administration" => "Administration",
						"tclrehash" => "TCL rehash"
					);
					
	// mainlog.php
	$lang_mainlog = array(
						"mainloglegend" => "Hauptlog",
						"logerased" => "Hauptlog wurde gel�scht.", 
						"erasemainlogbutton" => "L�sche Hauptlog"
					);
					
	// vlist.php
	$lang_vlist = array(
						"createuserlegend" => "Erstelle Nutzer",
						"description" => "Beschreibung",
						"value" => "Wert",
						"username" => "Benutzername",
						"password" => "Passwort",
						"randomempty" => "Leerlassen fuer zufaelliges Passwort",
						"server" => "Server",
						"port" => "Port",
						"create" => "Erstelle",
						"failedcreateuser" => "Erstellung des Nutzers %s fehlgeschlagen.", // %s is username
						"failedtocreateuserquota" => "Quote erreicht. Du hast schon %s Nutzer.", // %s is number of users
						"usercreated" => "Nutzer %s wurde erstellt. Passwort: %s", // %s is username 
						"deleteuserlegend" => "L�sche Nutzer",
						"cantdeleteown" => "Du kannst dich selbst nicht l�schen.",
						"usernotdeleted" => "Nutzer konnte nicht gel�scht werden: ",
						"userdeleted" => "Nutzer %s wurde gel�scht.", // %s is username
						"deletedconfirmation" => "M�chtest du den Nutzer %s wirklich l�schen?", // %s is username
						"deletebutton" => "L�sche",
						"userslegend" => "Benutzer",
						"user" => "Benutzer",
						"channels" => "Kan�le",
						"uptime" => "Uptime",
						"client" => "Client",
						"level" => "Level",
						"suspended" => "Gesperrt",
						"action" => "Aktion",
						"no" => "Nein",
						"yes" => "Ja",
						"virtualadministrator" => "Virtueller Administrator",
						"delete" => "L�sche",
						"do" => "do",
						"createuserbutton" => "Erstelle Nutzer",				
						"resetpass" => "Passwort resetten.",
						"changepasswordlegend" => "Password veraendern",
						"done" => "Erledigt.",
						"set" => "Setze"
					);
					
		// language.php
		$lang_language = array(
						"langlegend" => "Sprache",
						"languageset" => "Sprache wurde gesetzt auf: %s.", // %s is language
						"currentlang" => "Die aktuelle Spracheinstellung ist: %s.", // %s is language
						"changeto" => "Wechsle zu: ",
						"set" => "Setze",
						"none" => "Keine",
						"de" => "Deutsch",
						"en" => "English",
						"sw" => "Svenska",
						"nl" => "Nederlands",
						"fi" => "Suomen kieli",
						"dk" => "dansk"
					);
					
					
		// userlist.php
		$lang_ulist = array(
						"users" => "Nutzer",
						"createuser" => "Erstelle Nutzer",
						"description" => "Beschreibung",
						"value" => "Wert",
						"username" => "Nutzername",
						"password" => "Passwort",
						"emptyforrandompass" => "Leerlassen f�r zuf�lliges Passwort",
						"server" => "Server",
						"port" => "Port",
						"ident" => "Ident",
						"emptyusernameident" => "wenn leer, ist der ident der nutzername",
						"create" => "Erstelle",
						"isercreatinglegend" => "Erstelle Nutzer",
						"failedcreateuser" => "Erstellung des Nutzers Fehlgeschlagen.",
						"usercreate" => "Nutzer %s wurde erstellt mit dem Passwort: %s.", // %s is username, %s is password
						"jump" => "Jump",
						"done" => "erledigt." ,
						"successfullykilledclient" => "Clientverbindung erfolgreich getrennt: ",
						"usertokill" => "Zu trennender Benutzer: ",
						"reason" => "Grund: ",
						"kill" => "kill",
						"logerasedlegend" => "L�sche log",
						"successfullyerasedlog" => "Log erfolgreich gel�scht: ",
						"logof" => "Log von: ",
						"delete" => "l�sche",
						"successfullykilledserver" => "Serververbindung erfolgreich getrennt von:",
						"usertodisconnect" => "Zutrennender Nutzer: ",
						"disconnect" => "Trenne",
						"messagesendlegend" => "Nachricht senden",
						"messagesend" => "Nachricht zum Nutzer %s gesendet: %s.", // %s is username, %s is message
						"sendmessage" => "Sende Nachricht",
						"send" => "Sende",
						"chaninfoabout" => "Kanalinformation �ber: %s",
						"channel" => "Kanal",
						"channelmodes" => "Kanalmodes",
						"topic" => "Thema", 
						"users" => "Nutzer",
						"channelparted" => "Kanal verlassen",
						"successfullyjoinedchannel" => "%s hat den Kanal %s erfolgreich betreten.", // %s is username, %s is channel
						"channeljoined" => "Kanal betreten",
						"successfullypartedchannel" => "%s hat den Kanal %s erfolgreicht verlassen.",  // %s is username, %s is channel
						"part" => "Verlasse",
						"user" => "Nutzer",
						"join" => "Betrete",
						"modes" => "Modes",
						"command" => "Kommando",
						"totalnumberofchannels" => "Anzahl der Kan�le: ",
						"notconnectedlegend" => "Nicht verbunden",
						"notconnected" => "Dieser Nutzer ist nicht verbunden.",
						"set" => "Setze",
						"name" => "Name",
						"value" => "Wert",
						"lock" => "Lock",
						"commit" => "Best�tige",
						"not connected" => "Nicht verbunden.",
						"jump" => "Jump",
						"Password" => "Passwort",
						"Server" => "Server",
						"Port" => "Port",
						"Nick" => "Nick",
						"Realname" => "Wirklicher Name",
						"Away-Nick" => "Away-Nick",
						"Away-Reason" => "Away-Grund",
						"Away-message" => "Away-Nachricht",
						"Vhost" => "Vhost",
						"Ident" => "Ident",
						"cantdeleteyourself" => "Du kannst dich selbst nicht l�schen.",
						"userdeletedlegend" => "Nutzer gel�scht.",
						"userdeleted" => "Nutzer %s wurde gel�scht.", // %s is username
						"usertodeletelegend" => "Zu l�schender Nutzer: %s",  // %s is username
						"usercreated" => "Nutzer %s wurde mit dem Passwort %s erstellt.",
						"usertodelete" => "M�chtest du den Nutzer %s wirklich l�schen?", 
						"changinggrouplegend" => "Wechsle Gruppe",
						"cannotchangegroup" => "Die Gruppe von %s kann nicht ver�ndert werden.", // %s is username
						"removeduserfromgroup" => "Nutzer %s von allen Gruppen entfernt.", // %s is username
						"changedgroupofuser" => "Gruppe des Nutzers %s ver�ndert auf: %s.", // %s is username %s is group
						"changinggroupto" => "Ver�ndere Gruppe von %s (aktuelle Gruppe: %s) nach:", // %s is username, %s is groupname
						"nogroupavailable" => "Keine Gruppe verf�gbar",
						"none" => "keine",
						"cantremoveownadmin" => "Du kannst deinen eigenen Adminstatus nicht l�schen.",
						"usernotchanged" => "Nutzer konnte nicht ver�ndert werden.",
						"usernownoadmin" => "Nutzer %s ist nicht l�nger Administrator.",
						"usernowadmin" => "Nutzer %s ist nun Administrator.",
						"error" => "Fehler",
						"cannotsuspendyourself" => "Du kannst dich selbst nicht sperren.",
						"suspension" => "Sperrung",
						"usernolongersuspended" => "Nutzer %s ist nicht l�nger gesperrt.", // %s is username
						"usernowsuspended" => "Nutzer %s ist nun gesperrt. Grund: %s", // %s is username, %s is reason
						"suspensionoflegend" => "Sperrung von %s", // %s is username
						"suspend" => "Sperrung",
						"group" => "Gruppe ",
						"traffic" => "Traffic",
						"uptime" => "Uptime",
						"client" => "Client",
						"level" => "Level",
						"susp." => "Sper.",
						"action" => "Aktion",
						"no" => "Nein",
						"yes" => "Ja",
						"virtualadministrator" => "Virtueller Administrator",
						"administrator" => "Administrator",
						"user" => "Nutzer",
						"killclient" => "Beende Client",
						"killbouncer" => "Beende Bouncer", 
						"log" => "Log",
						"channels" => "Kan�le",
						"sendmessagebutton" => "Sende Nachricht",
						"do" => "do",
						"createuserbutton" => "Erstelle Nutzer",			
						"usercreatinglegend" => "Nutzer erstellt",
						"settingsforuser" => "Einstellung von %s",
						"emptylog" => "Das Log ist leer.",
						"clearhost" => "Hosts entfernen",
						"clearhostlegend" => "Hosts von %s entfernt.",
						"key" => "Schluessel:"
					);
			$lang_hosts = array(
						"add" => "Hinzuf�gen",
						"remove" => "Entfernen",
						"hosts" => "Hosts",
						"done" => "Erledigt.",
						"action" => "Aktion"
					);
?>
