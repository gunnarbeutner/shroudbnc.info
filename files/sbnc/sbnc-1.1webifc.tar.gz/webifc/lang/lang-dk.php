<?php
    /*****************************************************
     *    Danish language file for webinterface by webzi                  *
     ******************************************************/

     // index.php
     $lang_index = array(
                        "htmltitle" => "shroudBNC Webinterface",
                        "title" => "shroudBNC Webinterface",
                        "logoutlegend" => "Logud",
                        "logoutlink" => "Du er nu logget ud. Klik <a href='login.php'>her</a> For at logge ind igen.",
                        "user" => "Bruger",
                        "info" => "info",
                        "settings" => "Ops�tning",
                        "channels" => "Kanaler",
                        "log" => "log",
                        "qauth" => "qauth",
                        "contact" => "kontakt",
                        "logout" => "logud",
                        "vadmin" => "vadmin",
			"hosts" => "hosts",
                        "vlist" => "brugerliste",
                        "vgroups" => "vgroups",
                        "admin" => "admin",
                        "global" => "global",
                        "userlist" => "bruger liste",
                        "mainlog" => "mainlog",
                        "language" => "sprog",
                        "login" => "Login",
                        "select" => "v�lg"
                    );
                        
    
     // info.php
    $lang_info = array(
                        "accountinfo" => "Information om din konto",
                        "username" => "brugernavn",
                        "currentnick" => "IRC nick",
                        "uptime" => "Oppetid",
                        "client" => "Client",
                        "none" => "None",
                        "server" => "Server",
                        "notconnected" => "Ikke connected",
                        "traffic" => "Trafik",
                        "in" => "Ind",
                        "out" => "Ud",
                        "totaltraffic" => "Total trafik",
                        "level" => "Level",
                        "user" => "bruger",
                        "administrator" => "Administrator",
                        "virtualadministrator" => "Virtual Administrator"
                        );
    
    // settings.php
    $lang_settings = array(
                        "jump" => "hop",
                        "reconnect" => "Reconnecter...",
                        "settings" => "Ops�tning",
                        "name" => "Navn",
                        "value" => "Value",
                        "commit" => "Commit",
                        "Password" => "kode",
                        "Server" => "Server",
                        "Port" => "Port",
                        "Nick" => "Navn",
                        "Realname" => "Rigtige navn",
                        "Away-Nick" => "Away-nick",
                        "Away-Reason" => "Away-grund",
                        "Away-message" => "Away-besked",
                        "Vhost" => "Vhost",
                        "set" => "Set",
                        "settingschanged" => "�ndringer er blevet gemt",
                        "settingsonlyreconnect" => " (Du skal bruge commmand /jump for at instillingerne �ndres)",
                        "full" => "fuld",
                        "notfull" => "ikke fuld"
                        );
    
    // channels.php
    $lang_channels = array(
                        "partlegend" => "Forlader kanal",
                        "part" => "Forladt kanal %s", // %s == channel name
                        "joinlegend" => "Joiner kanal",
                        "join" => "Joinet kanal %s", // %s == channel name
                        "channel" => "Kanal",
                        "chanmodes" => "Chanmodes",
                        "topic" => "Topic",
                        "users" => "Brugere",
                        "channellegend" => "Kanaler",
                        "command" => "Command",
                        "totalchannels" => "Antal kanaler: ",
                        "notconnected" => "Du er IKKE connected.",
                        "partbutton" => "Forlad",    
                        "joinchannel" => "Join kanal: ",
                        "joinbutton" => "Join",
			"key" => "N�gle:"           
                    );
    
    // log.php
    $lang_log = array(
                        "logerase" => "Log er slettet.",
                        "erasebutton" => "slet log",
                        "loglegend" => "Privat log",
                        "logempty" => "Loggen er tom."
                    );
                    
    // qauth.php
    $lang_qauth = array(
                        "qauthlegend" => "Qauth",
                        "done" => "done.",
                        "note" => "Note: </b> Din kode og dit brugernavn vil blive gemt men vil ikke blive krypteret!",
                        "username" => "brugernavn:",
                        "password" => "kode:",
                        "umodex" => "umode x:",
                        "set" => "Set"
                    );
                    
    // contact.php
    $lang_contact = array(
                        "email" => "email",
                        "messagesendlegend" => "send besked",
                        "messagesend" => "F�lgende besked blev sendt: ",
                        "contactlegend" => "Kontakt",
                        "ownemail" => "egen email:*",
                        "message" => "Besked: ",
                        "send" => "Send",
                        "notelogcheck" => "Check din log indimellem (eller email, hvis valgt).",
                        "optional" => "felter med * skal udfyldes"
                    );

    // vgroups.php
    $lang_vgroups = array(
                        "cantunadmin" => "Du kan ikke fjerne dine egne administrator retighedder.",
                        "virtualadministratorlegend" => "Virtual Administrator",
                        "cantchangeuser" => "Bruger kunne ikke �ndres.",
                        "nolongervadmin" => "Bruger %s er ikke l�ngere virtual admin.",
                        "nowvadmin" =>     "Bruger %s er nu virtual admin.",
                        "usersofgroup" => "Brugere af gruppe %s", // %s er gruppenavn
                        "user" => "Bruger",
                        "level" => "Level",
                        "virtualadministrator" => "Virtual Administrator",
                        "newlimit" => "Nyt limit for gruppe %s sat til: %s",  // F�rste %s er gruppenavn, andet %s er det nye limit
                        "setnewlimitlegend" => "S�t limit for gruppe %s", // %s er gruppenavn
                        "setlimitlegend" => "Nyt limit sat",
                        "set" => "Set",
                        "creategrouplegend" => "Opret Gruppe",
                        "groupcreated" => "Gruppe %s blev oprettet. En bruger med det samme brugernavn og kode %s blev oprettet.",
                        "desc" => "signalement.",
                        "name" => "Navn",
                        "limit" => "Limit",
                        "value" => "V�rdig",
                        "createbutton" => "Opret",
                        "deletegrouplegend" => "Slet gruppe",
                        "groupnotdeleted" => "Gruppe kunne ikke slettes: ",
                        "groupwasdeleted" => "Gruppe %s Blev fjernet.", // %s is groupname
                        "deletegrouplegend" => "slet Gruppe %s", // %s is groupname
                        "deleteconfirmation" => "Vil du virkeligt slette gruppe %s?", // %s is groupname
                        "delete" => "slet",
                        "group" => "Gruppe",
                        "groups" => "Grupper",
                        "users" => "Brugere",
                        "action" => "Action",
                        "setlimit" => "set limit",
                        "do" => "do",
                        "nogroups" => "der er ingen grupper.",
                        "creategroupbutton" => "Opret grupper",
                        "failedcreate" => "Oprettelse mislykkedes: ",            
                        "failedlimitlegend" => "Nyt limit ikke sat",
                        "newlimitfailed" => "Kunne ikke s�tte nyt limit for %s" // %s is groupname
                    );
                    
    // global.php
    $lang_global = array(
                        "globalnoticelegend" => "Global notice",
                        "successfullysend" => "sendt korrekt: ",
                        "bncdisconnectedlegend" => "BNC afbrudt",
                        "bouncerkilled" => "Bnc'n er blevet dr�bt.",
                        "dielegend" => "d�",
                        "dieconfirmation" => "Vil du virkeligt dr�be denne bnc?",
                        "die" => "d�",
                        "TCLsuccessfullrehash" => "TCL er blevet rehashed.",
                        "TCLlegend" => "TCL",
                        "globallegend" => "Global",
                        "globalnoticelegend" => "Global Notice",
                        "send" => "send",
                        "administration" => "Administration",
                        "tclrehash" => "TCL rehash"
                    );
                    
    // mainlog.php
    $lang_mainlog = array(
                        "mainloglegend" => "Main log",
                        "logerased" => "Main log er blevet slettet.",
                        "erasemainlogbutton" => "slet main log"
                    );
                    
    // vlist.php
    $lang_vlist = array(
                        "createuserlegend" => "Opret Bruger",
                        "description" => "signalement",
                        "value" => "V�rdi",
                        "username" => "Brugernavn",
                        "password" => "Kodeord",
                        "randomempty" => "tilf�ldig , hvis feltet efterlades tomt",
                        "server" => "Server",
                        "port" => "Port",
                        "create" => "Opret",
                        "failedcreateuser" => "Bruger ikke oprettet %s.", // %s is username
                        "failedtocreateuserquota" => "Loft n�et, du har allerede %s brugere.", // %s is number of users
                        "usercreated" => "Bruger %s er oprettet med kode: %s", // %s is username, %s is pass
                        "deleteuserlegend" => "slet bruger",
                        "cantdeleteown" => "Stop med at tro du er sjov, du kan ikke slette dig selv.",
                        "usernotdeleted" => "Bruger kunne ikke slettes: ",
                        "userdeleted" => "Bruger %s er fjernet.", // %s is username
                        "deletedconfirmation" => "er du sikker p� du vil slette bruger %s?", // %s is username
                        "deletebutton" => "slet",
                        "userslegend" => "brugere",
                        "user" => "bruger",
                        "channels" => "Kanaler",
                        "uptime" => "Oppetid",
                        "client" => "Client",
                        "level" => "Level",
                        "suspended" => "inddraget",
                        "action" => "handling",
                        "no" => "Nej",
                        "yes" => "Ja",
                        "virtualadministrator" => "Virtual Administrator",
                        "delete" => "Slet",
                        "do" => "do",
                        "createuserbutton" => "Opret bruger",
                        "done" => "F�rdig.",
                        "resetpass" => "nulstil kodeord",
                        "changepasswordlegend" => "Skift kode",
                        "set" => "s�t"
                                        
                    );
                    
        // language.php
        $lang_language = array(
                        "langlegend" => "Sprog",
                        "languageset" => "Sprog er sat til %s.", // %s is language
                        "currentlang" => "Dit nuv�rende sprog er: %s.", // %s is language
                        "changeto" => "Skift til: ",
                        "set" => "S�t",
                        "none" => "None",
                        "dk" => "Dansk",                    
                        "en" => "English",                
                        "de" => "Deutsch",                                   
                        "sw" => "Swedish",
			"nl" => "Nederlands",
			"fi" => "Suomen kiele"
                     );
        // userlist.php
        $lang_ulist = array(
                        "users" => "Brugere",
                        "createuser" => "Opret bruger",
                        "description" => "Signalement",
                        "value" => "V�rdig",
                        "username" => "Brugernavn",
                        "password" => "Kodeord",
                        "emptyforrandompass" => "Hvis tomt, bliver det et automatisk password",
                        "server" => "Server",
                        "port" => "Port",
                        "ident" => "Ident",
                        "emptyusernameident" => "Hvis tomt, bliver ident det samme som brugernavn",
                        "create" => "Opret",
                        "isercreatinglegend" => "Opetter bruger",
                        "failedcreateuser" => "Oprettelse af bruger mislykket",
                        "usercreate" => "Bruger %s Blev oprettet med kode: %s.", // %s is username, %s is password
                        "jump" => "hop",
                        "done" => "F�rdig." ,
                        "successfullykilledclient" => "Client er dr�bt:",
                        "usertokill" => "Bruger som kan dr�bes: ",
                        "reason" => "Grund: ",
                        "kill" => "Dr�b",
                        "logerasedlegend" => "slet log",
                        "successfullyerasedlog" => "log er slettet: ",
                        "logof" => "Log for: ",
                        "delete" => "slet",
                        "successfullykilledserver" => "Server dr�bt:",
                        "usertodisconnect" => "Brugere som kan afbrydes: ",
                        "disconnect" => "Afbryd!",
                        "messagesendlegend" => "Send besked",
                        "messagesend" => "Besked til bruger %s send: %s.", // %s is username, %s is message
                        "sendmessage" => "Send besked",
                        "send" => "Send",
                        "chaninfoabout" => "Kanal info for %s",
                        "channel" => "Kanal",
                        "channelmodes" => "Kanalmodes",
                        "topic" => "Topic",
                        "users" => "brugere",
                        "channelparted" => "Kanal forladt",
                        "successfullyjoinedchannel" => "%s indtr�dte p� %s.", // %s is username, %s is channel
                        "channeljoined" => "Kannal �bnet",
                        "successfullypartedchannel" => "%s Har nu forladt %s.",  // %s is username, %s is channel
                        "part" => "Forlad",
                        "user" => "Bruger",
                        "join" => "Join",
                        "modes" => "Modes",
                        "command" => "Command",
                        "totalnumberofchannels" => "Antal kanaler: ",
                        "notconnectedlegend" => "Ikke forbundet",
                        "notconnected" => "Brugeren er ikke forbundet med en server.",
                        "set" => "Set",
                        "name" => "navn",
                        "value" => "v�rdi",
                        "lock" => "L�s",
                        "commit" => "Commit",
                        "not connected" => "Ikke forbundet.",
                        "jump" => "hop",
                        "Password" => "Kode",
                        "Server" => "Server",
                        "Port" => "Port",
                        "Nick" => "Nick",
                        "Realname" => "Rigtige navn",
                        "Away-Nick" => "Away-navn",
                        "Away-Reason" => "Away-grund",
                        "Away-message" => "Away-besked",
                        "Vhost" => "Vhost",
                        "Ident" => "Ident",
                        "cantdeleteyourself" => "Tror du at du er sjov? Du kan ikke slette dig selv.",
                        "userdeletedlegend" => "Bruger slettet.",
                        "userdeleted" => "Bruger %s er slettet.", // %s is username
                        "usertodeletelegend" => "slet bruger: %s",  // %s is username
                        "usercreated" => "Bruger %s er oprettet med kode: %s.",
                        "usertodelete" => "Vil du virkeligt slette %s?",
                        "changinggrouplegend" => "Skifter Gruppe",
                        "cannotchangegroup" => "kan ikke skifte gruppe for bruger %s.", // %s is username
                        "removeduserfromgroup" => "Fjernet bruger %s fra alle grupper.", // %s is username
                        "changedgroupofuser" => "Skiftet gruppe fra %s til %s.", // %s is username %s is group
                        "changinggroupto" => "Skift gruppe for bruger: %s (nuv�rende gruppe: %s) to:", // %s is username, %s is groupname
                        "nogroupavailable" => "Ingen gruppe ledig",
                        "none" => "ingen",
                        "cantremoveownadmin" => "Du kan ikke fjerne dine administrator retighedder.",
                        "usernotchanged" => "bruger kunne ikke �ndres.",
                        "usernownoadmin" => "Bruger %s er ikke l�ngere admin",
                        "usernowadmin" => "Bruger %s er nu admin",
                        "error" => "fejl",
                        "cannotsuspendyourself" => "Du kan ikke suspenderer dig selv.",
                        "suspension" => "Suspendering",
                        "usernolongersuspended" => "Bruger %s er ikke l�ngere suspenderet.", // %s is username
                        "usernowsuspended" => "Bruger %s er nu suspenderet. grund: %s.", // %s is username, %s is reason
                        "suspensionoflegend" => "Suspendering af: %s", // %s is username
                        "suspend" => "Suspender",
                        "group" => "Gruppe ",
                        "traffic" => "Trafik",
                        "channels" => "Kanaler",
                        "uptime" => "Oppetid",
                        "client" => "Client",
                        "level" => "Level",
                        "susp." => "Susp.",
                        "action" => "Handling",
                        "no" => "Nej",
                        "yes" => "ja",
                        "virtualadministrator" => "Virtual Administrator",
                        "administrator" => "Administrator",
                        "user" => "Bruger",
                        "killclient" => "Dr�b klient",
                        "killbouncer" => "Dr�b bouncer",
                        "log" => "log",
                        "sendmessagebutton" => "send besked",
                        "do" => "do",
                        "createuserbutton" => "Opret bruger",            
                        "usercreatinglegend" => "Bruger oprettet",
                        "settingsforuser" => "Ops�tning for bruger %s",
                        "emptylog" => "Log er tom.",
                        "clearhost" => "Klar hosts",
			"clearhostlegend" => "Hosts af %s slettet",
			"key" => "N�gle:"
	          );

	$lang_hosts = array(
			"add" => "tilf�j",
			"remove" => "fjern",
			"done" => "f�rdig.",
			"hosts" => "hosts",
			"action" => "handling"
			);

?>

