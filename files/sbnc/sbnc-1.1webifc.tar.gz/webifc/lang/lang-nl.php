<?php
    /*****************************************************
    *    Dutch language file for webinterface            *
    *****************************************************/

    // index.php
    $lang_index = array(
                        "htmltitle" => "shroudBNC Webinterface",
                        "title" => "shroudBNC Webinterface",
                        "logoutlegend" => "Uitloggen",
                        "logoutlink" => "Je bent nu uitgelogd. Klik <a href='login.php'>hier</a> om opnieuw in te loggen.",
                        "user" => "Gebruiker",
                        "info" => "info",
                        "settings" => "instellingen",
                        "channels" => "kanalen",
                        "log" => "log",
                        "qauth" => "qauth",
                        "contact" => "contact",
                        "logout" => "uitloggen",
                        "vadmin" => "vadmin",
			"hosts" => "hosts",
                        "vlist" => "gebruikerslijst",
                        "vgroups" => "vgroepen",
                        "admin" => "admin",
                        "global" => "globaal",
                        "userlist" => "gebruikerslijst",
                        "mainlog" => "mainlog",
                        "language" => "taal" ,
                        "login" => "Inloggen",
                        "select" => "Selecteer"
                    );

    // info.php
    $lang_info = array(
                        "accountinfo" => "Informatie over uw account",
                        "username" => "Gebruikersnaam",
                        "currentnick" => "Huidige Nick",
                        "uptime" => "Uptime",
                        "client" => "Client",
                        "none" => "Geen",
                        "server" => "Server",
                        "notconnected" => "Niet verbonden",
                        "traffic" => "Verkeer",
                        "in" => "In",
                        "out" => "Uit",
                        "totaltraffic" => "Totaal verkeer",
                        "level" => "Level",
                        "user" => "Gebruiker",
                        "administrator" => "Administrator",
                        "virtualadministrator" => "Virtual Administrator"
                    );

    // settings.php
    $lang_settings = array(
                        "jump" => "Jump",
                        "reconnect" => "Opnieuw verbinden...",
                        "settings" => "Instellingen",
                        "name" => "Naam",
                        "value" => "Waarde",
                        "commit" => "ingeven",
                        "Password" => "Paswoord",
                        "Server" => "Server",
                        "Port" => "Poort",
                        "Nick" => "Nick",
                        "Realname" => "Echte naam",
                        "Away-Nick" => "Away-nick",
                        "Away-Reason" => "Away-reden",
                        "Away-message" => "Away-message",
                        "Vhost" => "Vhost",
                        "set" => "Set",
                        "settingschanged" => "Instellingen werden opgeslaan.",
                        "settingsonlyreconnect" => " (Je zal opnieuw moeten verbinden/JUMP om de aanpassingen te activeren)",
                        "full" => "vol",
                        "notfull" => "niet vol"
                        );

    // channels.php
    $lang_channels = array(
                        "partlegend" => "Bezig kanaal te verlaten",
                        "part" => "Kanaal %s verlaten", // %s == channel name
                        "joinlegend" => "Bezig kanaal te joinen",
                        "join" => "Kanaal %s gejoind", // %s == channel name
                        "channel" => "Kanaal",
                        "chanmodes" => "Chanmodes",
                        "topic" => "Topic",
                        "users" => "Gebruikers",
                        "channellegend" => "Kanalen",
                        "command" => "Command",
                        "totalchannels" => "Totaal aantal kanalen: ",
                        "notconnected" => "Je bent niet verbonden.",
                        "partbutton" => "Verlaat",   
                        "joinchannel" => "Kanaal joinen: ",
                        "joinbutton" => "Join",
			"key" => "Toonschaal:"
                    );

    // log.php
    $lang_log = array(
                        "logerase" => "Log is verwijderd.",
                        "erasebutton" => "Verwijder log",
                        "loglegend" => "Priv� log" ,
                        "logempty" => "Log is leeg."
                    );

    // qauth.php 
    $lang_qauth = array(
                        "qauthlegend" => "Qauth",
                        "done" => "klaar.",
                        "note" => "Note: </b>Je paswoord en gebruikersnaam zullen ongecodeerd opgeslaan worden! Gebruik deze functie enkel als je daarmee akkoord gaat en je ook echt verbonden bent met QuakeNet!",
                        "username" => "gebruikersnaam:",
                        "password" => "paswoord:",
                        "umodex" => "umode x:",
                        "set" => "Instellen"
                    );

    // contact.php
    $lang_contact = array(
                        "email" => "e-mail",
                        "messagesendlegend" => "Bericht verstuurd",
                        "messagesend" => "Volgend bericht werd verstuurd: ",
                        "contactlegend" => "Contact",
                        "ownemail" => "eigen email:*",
                        "message" => "bericht: ",
                        "send" => "Verzenden",
                        "notelogcheck" => "Bekijk je log regelmatig (of emailaccount, indien ingesteld).",
                        "optional" => "* optioneel"
                    );

    // vgroups.php
    $lang_vgroups = array(
                        "cantunadmin" => "Je kan je eigen administrator privileges niet verwijderen.",
                        "virtualadministratorlegend" => "Virtual Administrator",
                        "cantchangeuser" => "Gebruiker kon niet veranderd worden.",
                        "nolongervadmin" => "Gebruiker %s is geen virtual admin meer.",
                        "nowvadmin" => "Gebruiker %s is nu virtual admin.",
                        "usersofgroup" => "Gebruikers van groep %s", // %s is groupname
                        "user" => "Gebruiker",
                        "level" => "Level",
                        "virtualadministrator" => "Virtual Administrator",
                        "newlimit" => "Nieuw limiet voor groep %s is ingesteld op: %s", // first %s is groupname,second %s is the new limit
                        "setnewlimitlegend" => "Limiet voor groep %s is ingesteld op", // %s is groupname
                        "setlimitlegend" => "Nieuw limiet werd ingesteld",
                        "set" => "Instellen",
                        "creategrouplegend" => "Maak groep",
                        "groupcreated" => "Groep %s werd gemaakt. Er werd ook een bijkomende gebruiker gemaakt met dezelfde naam en paswoord %s.",
                        "desc" => "Beschrijving",
                        "name" => "Naam",
                        "limit" => "Limiet",
                        "value" => "Waarde",
                        "createbutton" => "Maak",
                        "deletegrouplegend" => "Verwijder Groep",
                        "groupnotdeleted" => "Groep kon niet verwijderd worden: ",
                        "groupwasdeleted" => "Groep %s werd verwijderd.", // %s is groupname
                        "deletegrouplegend" => "Verwijder Groep %s", // %s is groupname
                        "deleteconfirmation" => "Wilt u echt groep %s verwijderen?", // %s is groupname
                        "delete" => "verwijder",
                        "group" => "Groep",
                        "groups" => "Groepen",
                        "users" => "gebruikers",
                        "action" => "Actie",
                        "setlimit" => "stel limiet in",
                        "do" => "do",
                        "nogroups" => "Er zijn geen groepen.",
                        "creategroupbutton" => "Maak groep",
                        "failedcreate" => "Groep maken mislukt: ",
                        "failedlimitlegend" => "Nieuw limiet niet ingesteld",
                        "newlimitfailed" => "Kon nieuw limiet niet instellen voor %s" // %s is groupname
                    );

    // global.php
    $lang_global = array(
                        "globalnoticelegend" => "Globale notice",
                        "successfullysend" => "Succesvol verzonden: ",
                        "bncdisconnectedlegend" => "BNC disconnected",
                        "bouncerkilled" => "De bouncer werd gekilld.",
                        "dielegend" => "die",
                        "dieconfirmation" => "Wilt u echt de bnc killen?",
                        "die" => "die",
                        "TCLsuccessfullrehash" => "TCL werd succesvol rehashed.",
                        "TCLlegend" => "TCL",
                        "globallegend" => "Globaal",
                        "globalnoticelegend" => "Globale Notice",
                        "send" => "verstuur",
                        "administration" => "Administratie",
                        "tclrehash" => "TCL rehash"
                    );

    // mainlog.php
    $lang_mainlog = array(
                        "mainloglegend" => "Main log",
                        "logerased" => "Main log werd verwijderd.",
                        "erasemainlogbutton" => "Verwijder main log"
                    );

    // vlist.php
    $lang_vlist = array(
                        "createuserlegend" => "Maak Gebruiker",
                        "description" => "Beschrijving",
                        "value" => "Waarde",
                        "username" => "Gebruikersnaam",
                        "password" => "Paswoord",
                        "randomempty" => "willekeuring, indien leeg",
                        "server" => "Server",
                        "port" => "Poort",
                        "create" => "Maak",
                        "failedcreateuser" => "Mislukt om gebruiker %s te maken", // %s is username
                        "failedtocreateuserquota" => "Quota bereikt. Je hebt al %s gebruikers.", // %s is number of users
                        "usercreated" => "Gebruiker %s werd gemaakt met paswoord: %s", // %s is username,%s is pass
                        "deleteuserlegend" => "Verwijder gebruiker",
                        "cantdeleteown" => "Stop met grappig te proberen zijn. Je kan jezelf niet verwijderen.",
                        "usernotdeleted" => "Gebruiker kon niet verwijderd worden: ",
                        "userdeleted" => "Gebruiker %s werd verwijderd.", // %s is username
                        "deletedconfirmation" => "Wilt u echt gebruiker %s verwijderen?", // %s is username
                        "deletebutton" => "verwijder",
                        "userslegend" => "Gebruikers",
                        "user" => "Gebruikers",
                        "channels" => "Kanalen",
                        "uptime" => "Uptime",
                        "client" => "Client",
                        "level" => "Level",
                        "suspended" => "Geschorst",
                        "action" => "Actie",
                        "no" => "Nee",
                        "yes" => "Ja",
                        "virtualadministrator" => "Virtual Administrator",
                        "delete" => "verwijder",
                        "do" => "do",
                        "createuserbutton" => "Maak Gebruiker",
                        "done" => "done.",
                        "resetpass" => "reset paswoord",
                        "changepasswordlegend" => "Verander paswoord",
                        "set" => "Set"
                    );

    // language.php
    $lang_language = array(
                        "langlegend" => "Taal",
                        "languageset" => "Taal werd veranderd naar %s.", // %s is language
                        "currentlang" => "Je huidige taal is: %s.", // %s is language
                        "changeto" => "Verander naar: ",
                        "set" => "Set",
                        "none" => "Geen",
                        "de" => "Duits",
                        "en" => "Engels",
                        "nl" => "Nederlands",
                        "sw" => "Zweeds",
			"fi" => "Suomen kieli",
			"dk" => "Dansk"
                    );

    // userlist.php
    $lang_ulist = array(
                        "users" => "Gebruikers",
                        "createuser" => "Maak Gebruiker",
                        "description" => "Beschrijving",
                        "value" => "Waarde",
                        "username" => "Gebruikersnaam",
                        "password" => "Paswoord",
                        "emptyforrandompass" => "Laat blanco voor een willekeurig paswoord",
                        "server" => "Server",
                        "port" => "Poort",
                        "ident" => "Ident",
                        "emptyusernameident" => "indien leeg, dan is ident de gebruikernaam",
                        "create" => "Maak",
                        "isercreatinglegend" => "Bezig gebruiker te maken",
                        "failedcreateuser" => "Mislukt om gebruiker te maken",
                        "usercreate" => "Gebruiker %s werd gemaakt met paswoord: %s.", // %s is username,%s is password
                        "jump" => "Jump",
                        "done" => "klaar." ,
                        "successfullykilledclient" => "Succesvol de client connectie gekilld:",
                        "usertokill" => "Gebruiker om te killen: ",
                        "reason" => "reden: ",
                        "kill" => "kill",
                        "logerasedlegend" => "Verwijder log",
                        "successfullyerasedlog" => "Log werd succesvol verwijderd: ",
                        "logof" => "Log van: ",
                        "delete" => "verwijder",
                        "successfullykilledserver" => "Server connectie werd succesvol gekilld:",
                        "usertodisconnect" => "Gebruiker om te disconnecten: ",
                        "disconnect" => "Disconnect",
                        "messagesendlegend" => "Bericht verstuurd",
                        "messagesend" => "Bericht naar gebruiker %s werd verstuurd: %s.", // %s is username,%s is message
                        "sendmessage" => "Verstuur bericht",
                        "send" => "Verstuur",
                        "chaninfoabout" => "Kanaal info over %s",
                        "channel" => "Kanaal",
                        "channelmodes" => "Kanaalmodes",
                        "topic" => "Topic",
                        "users" => "Gebruikers",
                        "channelparted" => "Kanaal verlaten",
                        "successfullyjoinedchannel" => "%s is succesvol kanaal %s gejoind.", // %s is username,%s is channel
                        "channeljoined" => "Kanaal gejoind",
                        "successfullypartedchannel" => "%s heeft succesvol %s verlaten.", // %s is username,%s is channel
                        "part" => "Verlaat",
                        "user" => "Gebruiker",
                        "join" => "Join",
                        "modes" => "Modes",
                        "command" => "Command",
                        "totalnumberofchannels" => "Totaal aantal kanalen: ",
                        "notconnectedlegend" => "Niet verbonden",
                        "notconnected" => "Deze gebruiker is niet verbonden.",
                        "set" => "Instellen",
                        "name" => "Naam",
                        "value" => "Waarde",
                        "lock" => "Vastzetten",
                        "commit" => "Ingeven",
                        "not connected" => "Niet verbonden.",
                        "jump" => "Jump",
                        "Password" => "Paswoord",
                        "Server" => "Server",
                        "Port" => "Poort",
                        "Nick" => "Nick",
                        "Realname" => "Echte naam",
                        "Away-Nick" => "Away-Nick",
                        "Away-Reason" => "Away-Reden",
                        "Away-message" => "Away-Message",
                        "Vhost" => "Vhost",
                        "Ident" => "Ident",
                        "cantdeleteyourself" => "Stop met grappig te proberen zijn. Je kan jezelf niet verwijderen.",
                        "userdeletedlegend" => "Gebruiker verwijderd",
                        "userdeleted" => "Gebruiker %s werd verwijderd.", // %s is username
                        "usertodeletelegend" => "Gebruiker om te verwijderen: %s", // %s is username
                        "usercreated" => "Gebruiker %s werd gemaakt met paswoord: %s.",
                        "usertodelete" => "Wilt u echt gebruiker %s verwijderen?",
                        "changinggrouplegend" => "Bezig groep te veranderen",
                        "cannotchangegroup" => "Kan groep van gebruiker %s niet veranderen.", // %s is username
                        "removeduserfromgroup" => "Gebruiker %s van elke groep.", // %s is username
                        "changedgroupofuser" => "Groep van gebruiker verandert van %s naar %s.", // %s is username %s is group
                        "changinggroupto" => "Bezig groep te veranderen van gebruiker %s (huidige groep: %s) naar: ", // %s is username, %s is groupname
                        "nogroupavailable" => "Geen groep beschikbaar",
                        "none" => "geen",
                        "cantremoveownadmin" => "Je kan je eigen administrator privileges niet verwijderen.",
                        "usernotchanged" => "Gebruiker kon niet gevonden worden.",
                        "usernownoadmin" => "Gebruiker %s is niet langer admin",
                        "usernowadmin" => "Gebruiker %s is nu admin",
                        "error" => "Fout",
                        "cannotsuspendyourself" => "Je kan jezelf niet schorsen.",
                        "suspension" => "Schorsing",
                        "usernolongersuspended" => "Gebruiker %s is niet langer geschorst.", // %s is username
                        "usernowsuspended" => "Gebruiker %s is nu geschorst. Reden: %s.", // %s is username, %s is reason
                        "suspensionoflegend" => "Schorsing van: %s", // %s is username
                        "suspend" => "Schors",
                        "group" => "Groep ",
                        "traffic" => "Verkeer",
                        "channels" => "Kanalen",
                        "uptime" => "Uptime",
                        "client" => "Client",
                        "level" => "Level",
                        "susp." => "Gesch.",
                        "action" => "Actie",
                        "no" => "Nee",
                        "yes" => "Ja",
                        "virtualadministrator" => "Virtual Administrator",
                        "administrator" => "Administrator",
                        "user" => "Gebruiker",
                        "killclient" => "kill client",
                        "killbouncer" => "kill bouncer",
                        "log" => "log",
                        "sendmessagebutton" => "verstuur bericht",
                        "do" => "do",
                        "createuserbutton" => "Maak Gebruiker",
                        "usercreatinglegend" => "Gebruiker werd gemaakt",
                        "settingsforuser" => "Instellingen voor gebruiker %s",
                        "emptylog" => "Log is leeg.",
			"clearhost" => "verwijder host",
			"clearhostlegend" => "host van %s geleegd.",
			"key" => "Toonschaal:"
                    );
	$lang_hosts = array(
			"add" => "toevoegen",
			"remove" => "verwijderen",
			"hosts" => "hosts",
			"done" => "klaar.",
			"action" => "Actie"
		    
		);
	
	
?>
