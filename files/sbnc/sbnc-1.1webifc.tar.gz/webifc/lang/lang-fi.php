<?php
	/*****************************************************
	 *	Suomenkielen tiedosto Webhallinalle		          *
	 ******************************************************/

	 // index.php
	 $lang_index = array(
 						"htmltitle" => "shroudBNC-Webhallinta",
						"title" => "shroudBNC-Webhallinta",
						"logoutlegend" => "Kirjaudu ulos",
						"logoutlink" => "Olet nyt kirjautunut ulos. Klikkaa <a href='login.php'>t�st�</a> kirjautuaksesi uudestaan.",
						"user" => "K�ytt�j�",
						"info" => "Info",
						"settings" => "Asetukset",
						"channels" => "Kanavat",
						"log" => "Logi",
						"qauth" => "Qauth",
						"contact" => "Ota yhteytt�",
						"hosts" => "Hosts",
						"logout" => "Kirjaudu ulos",
						"vadmin" => "Virtuaali Admin",
						"vlist" => "K�ytt�j�lista",
						"vgroups" => "Virtuaali ryhm�t",
						"admin" => "Admin",
						"global" => "Global",
						"userlist" => "K�ytt�j�lista",
						"mainlog" => "P��logit",
						"language" => "Kieli"
					);
						
	 
	 // info.php
	$lang_info = array(
						"accountinfo" => "Infoa tunnuksestasi",
						"username" => "K�ytt�j�nimi",
						"currentnick" => "Nickisi",
						"uptime" => "Online-aika",
						"client" => "Clientti",
						"none" => "None",
						"server" => "Serveri",
						"notconnected" => "Ei yhdistetty",
						"traffic" => "Liikenne",
						"in" => "Sis��n",
						"out" => "Ulos",
						"totaltraffic" => "Liikenne yhteens�",
						"level" => "Leveli",
						"user" => "User",
						"administrator" => "Admin",
						"virtualadministrator" => "Virtuaali Admin"
						);
	
	// settings.php
	$lang_settings = array(
						"jump" => "Jump",
						"reconnect" => "Reconnectitaan..",
						"settings" => "Asetukset",
						"name" => "Nimi",
						"value" => "Arvo",
						"commit" => "L�het�",
						"Password" => "Salasana",
						"Server" => "Serveri",
						"Port" => "Portti",
						"Nick" => "Nick",
						"Realname" => "Realname",
						"Away-Nick" => "Away-nick",
						"Away-Reason" => "Away-reason",
						"Away-message" => "Away-message",
						"Vhost" => "Vhost",
						"set" => "Aseta",
						"settingschanged" => "Asetukset tallennettu",
						"full" => "T�ysi",
						"notfull" => "Vapaata"
						);
	
	// channels.php
	$lang_channels = array(
						"partlegend" => "Partataan kanavaa",
						"part" => "Poistuttu kanavalta %s", // %s == channel name
						"joinlegend" => "Joinataan kanavalle",
						"join" => "Joinattu kanavalle %s", // %s == channel name
						"channel" => "Kanava",
						"chanmodes" => "Kanavan modet",
						"topic" => "Topic",
						"users" => "K�ytt�j�t",
						"channellegend" => "Kanavat",
						"command" => "Komento",
						"totalchannels" => "Kaikki kanavalt: ",
						"notconnected" => "Et ole yhdist�nyt.",
						"partbutton" => "Part",	
						"joinchannel" => "Joinaa kanavalle: ",
						"joinbutton" => "Join",
						"key" => "Avain:"		
					);
	
	// log.php
	$lang_log = array(
						"logerase" => "Logit poistettu.",
						"erasebutton" => "Poista logit",
						"loglegend" => "Privaatti logit",
						"logempty" => "Logit ovat tyhj�t."
					);
					
	// qauth.php 
	$lang_qauth = array(
						"qauthlegend" => "Qauth",
						"done" => "Tehty.",
						"note" => "Huom!: </b>Sinun salasanasi ja k�ytt�j�nimesi tallennetaan cryptaamattomana! Aktivoi se ainoastaan jos hyv�ksyt t�m�n ja jos olet yhdist�nyt QuakeNettiin!",
						"username" => "K�ytt�j�nimi:",
						"password" => "Salasana:",
						"umodex" => "K�ytt�j� mode +x:",
						"set" => "Aseta"
					);
					
	// contact.php
	$lang_contact = array(
						"email" => "Email",
						"messagesendlegend" => "Viesti l�hetetty",
						"messagesend" => "Seuraava viesti l�hetetty: ",
						"contactlegend" => "Ota yhteytt�",
						"ownemail" => "Oma email:*",
						"message" => "Viesti: ",
						"send" => "L�het�",
						"notelogcheck" => "Check your log regulary (or emailaccount, if specified).",
						"optional" => "* optional"
					);

	// vgroups.php
	$lang_vgroups = array(
						"cantunadmin" => "Et voi poistaa omia adminin oikeuksiasi",
						"virtualadministratorlegend" => "Virtuaali Admin",
						"cantchangeuser" => "K�ytt�j� ei voi vaihtua.",
						"nolongervadmin" => "K�ytt�j� %s ei ole en�� Virtuaali Admin.",
						"nowvadmin" => 	"K�ytt�j� %s on nyt Virtuaali Admin.",
						"usersofgroup" => "K�ytt�j�t ryhm�st� %s", // %s on ryhm�n nimi
						"user" => "K�ytt�j�",
						"level" => "K�ytt�j�taso",
						"virtualadministrator" => "Virtuaali Admin",
						"newlimit" => "Uusi raja ryhm�lle %s asetettu: %s",  // ensimm�inen %s on ryhm�n nimi, toinen %s on uusi raja
						"setnewlimitlegend" => "Aseta raja ryhm�lle %s", // %s on ryhm�n nimi
						"setlimitlegend" => "Uusi raja asetettu",
						"set" => "Aseta",
						"creategrouplegend" => "Tee ryhm�",
						"groupcreated" => "Ryhm� %s luotiin. Lis�ksi k�ytt�j� samalla nimella ja salasanalla %s luotiin.",
						"desc" => "Kuvaus",
						"name" => "Nimi",
						"limit" => "Raja",
						"createbutton" => "Tee",
						"deletegrouplegend" => "Poista ryhm�",
						"groupnotdeleted" => "Ryhm�� ei voi poistaa: ",
						"groupwasdeleted" => "Ryhm� %s poistettu.", // %s is groupname
						"deletegrouplegend" => "Poista ryhm� %s", // %s is groupname
						"deleteconfirmation" => "Haluatko varmasti poistaa ryhm�n %s?", // %s is groupname
						"delete" => "Poista",
						"group" => "Ryhm�",
						"groups" => "Ryhm�t",
						"users" => "K�ytt�j�t",
						"action" => "Action",
						"setlimit" => "Aseta raja",
						"do" => "Tee",
						"nogroups" => "Ei ole ryhmi�.",
						"creategroupbutton" => "Tee ryhm�",
						"failedcreate" => "Ryhm�n tekeminen ep�onnistunut: ",			
						"failedlimitlegend" => "Uutta rajaa ei ole asetettu",
						"newlimitfailed" => "Ei voitu asettaa uuta rajaa ryhm�lle %s" // %s is groupname
					);
					
	// global.php
	$lang_global = array(
						"globalnoticelegend" => "Global notice",
						"successfullysend" => "Onnistuneesti l�hetetty: ",
						"bncdisconnectedlegend" => "BNC disconnectannut",
						"bouncerkilled" => "BNC on tapettu.",
						"dielegend" => "Tapa prosessi",
						"dieconfirmation" => "Haluatko varmasti tappaan BNC:n?",
						"die" => "Tapa prosessi",
						"TCLsuccessfullrehash" => "TCL on onnistuneesti p�ivitetty",
						"TCLlegend" => "TCL",
						"globallegend" => "Global",
						"globalnoticelegend" => "Global Notice",
						"send" => "L�het�",
						"administration" => "Virtuaali Admin",
						"tclrehash" => "P�ivit� TCL"
					);
					
	// mainlog.php
	$lang_mainlog = array(
						"mainloglegend" => "P��logit",
						"logerased" => "P��logit poistettu.", 
						"erasemainlogbutton" => "Poista p��logit"
					);
					
	// vlist.php
	$lang_vlist = array(
						"createuserlegend" => "Lis�� k�ytt�j�",
						"description" => "Kuvaus",
						"value" => "Arvo",
						"username" => "K�ytt�j�nimi",
						"password" => "Salasana",
						"randomempty" => "Satunnaien, jos tyhj�",
						"server" => "Serveri",
						"port" => "Portti",
						"create" => "Tee",
						"failedcreateuser" => "Ep�onnistunut k�ytt�j�n tekeminen: %s", // %s is username
						"failedtocreateuserquota" => "Kiinti� t�yttynyt. Sinulla on jo %s k�ytt�j��.", // %s is number of users
						"usercreated" => "K�ytt�j� %s tehty salasanalla: %s", // %s is username, %s is pass
						"deleteuserlegend" => "Poista k�ytt�j�",
						"cantdeleteown" => "�l� yrit� olla hauska. Et voi poistaa itse�si.",
						"usernotdeleted" => "K�ytt�j�� ei voitu poistaa: ",
						"userdeleted" => "K�ytt�j� %s poistettu.", // %s is username
						"deletedconfirmation" => "Haluatko varmasti poistaa k�ytt�j�n %s?", // %s is username
						"deletebutton" => "Poista",
						"userslegend" => "K�ytt�j�t",
						"user" => "K�ytt�j�",
						"channels" => "Kanavat",
						"uptime" => "Online-aika",
						"client" => "Clientti",
						"level" => "K�ytt�j�taso",
						"suspended" => "Suspended",
						"action" => "Action",
						"no" => "Ei",
						"yes" => "Kyll�",
						"virtualadministrator" => "Virtuaali Admin",
						"delete" => "Poist�",
						"do" => "Tee",
						"createuserbutton" => "Lis�� k�ytt�j�",
						"done" => "Tehty.",
						"resetpass" => "Resetoi salasana",
						"changepasswordlegend" => "Vaihda salasana",
						"set" => "Aseta"
										
					);
					
		// language.php
		$lang_language = array(
						"langlegend" => "Kieli",
						"languageset" => "Kieli asetettu: %s.", // %s is language
						"currentlang" => "Sinun kielesi on: %s.", // %s is language
						"changeto" => "Vaihda: ",
						"set" => "Aseta",
						"none" => "Ei yht��n",
						"de" => "Saksa",
						"en" => "Englanti",
						"sw" => "Ruotsi",
						"fi" => "Suomen kieli",
						"nl" => "Nederlands",
						"dk" => "Dansk"
					);
					
					
		// userlist.php
		$lang_ulist = array(
						"users" => "K�ytt�j�t",
						"createuser" => "Lis�� k�ytt�j�",
						"description" => "Kuvaus",
						"value" => "Arvo",
						"username" => "K�ytt�j�nimi",
						"password" => "Salasana",
						"emptyforrandompass" => "J�t� tyhj� tila satunnaiselle salasanalle",
						"server" => "Serveri",
						"port" => "Portti",
						"ident" => "Tunnus",
						"emptyusernameident" => "Jos tyhj�, ident on k�ytt�j�nimi",
						"create" => "Tee",
						"isercreatinglegend" => "Tehd��n k�ytt�j��",
						"failedcreateuser" => "Ep�onnistuttu teht�ess� k�ytt�j��: ",
						"usercreate" => "K�ytt�j� %s on luotu salasanalla: %s.", // %s is username, %s is password
						"jump" => "Jump",
						"done" => "Tehty." ,
						"successfullykilledclient" => "Onnistuneesti tapettu clientti yhteys:",
						"usertokill" => "K�ytt�j� tapettavaksi: ",
						"reason" => "Syy: ",
						"kill" => "TAPA",
						"logerasedlegend" => "Poista logit",
						"successfullyerasedlog" => "Onnistuneesti poistettu logit: ",
						"logof" => "Logit: ",
						"delete" => "Poista",
						"successfullykilledserver" => "Onnnistuneesti tapettu serveri:",
						"usertodisconnect" => "K�ytt�j� disconnectettavaksi: ",
						"disconnect" => "Disconnectaa",
						"messagesendlegend" => "Viesti l�hetetty",
						"messagesend" => "Viesti k�ytt�j�lle %s l�hetetty: %s.", // %s is username, %s is message
						"sendmessage" => "L�het� viesti",
						"send" => "L�het�",
						"chaninfoabout" => "Kanavan info koskien %s",
						"channel" => "Kanava",
						"channelmodes" => "Kanavan modet",
						"topic" => "Topic", 
						"users" => "K�ytt�j�t",
						"channelparted" => "Kanava partattu",
						"successfullyjoinedchannel" => "%s Joinattu onnistuneesti %s.", // %s is username, %s is channel
						"channeljoined" => "Channel joined",
						"successfullypartedchannel" => "%s Partattu onnistuneesti %s.",  // %s is username, %s is channel
						"part" => "Parttaa",
						"user" => "K�ytt�j�",
						"join" => "Joinaa",
						"modes" => "Modet",
						"command" => "Komento",
						"totalnumberofchannels" => "Kaikki kanavat: ",
						"notconnectedlegend" => "Ei yhdistetty",
						"notconnected" => "T�m� k�ytt�j� ei ole yhdist�nyt.",
						"set" => "Aseta",
						"name" => "Nimi",
						"value" => "Arvo",
						"lock" => "Lukitse",
						"commit" => "L�het�",
						"not connected" => "Ei yhdistetty.",
						"jump" => "Jump",
						"Password" => "Salasana",
						"Server" => "Serveri",
						"Port" => "Portti",
						"Nick" => "Nick",
						"Realname" => "Realname",
						"Away-Nick" => "Away-Nick",
						"Away-Reason" => "Away-Reason",
						"Away-message" => "Away-Message",
						"Vhost" => "Vhost",
						"Ident" => "Tunnus",
						"cantdeleteyourself" => "�l� yrit� olla hauska. Et voi poistaa omaa tunnusta.",
						"userdeletedlegend" => "K�ytt�j� poistettu",
						"userdeleted" => "K�ytt�j� %s poistettu.", // %s is username
						"usertodeletelegend" => "Poistettava k�ytt�j�: %s",  // %s is username
						"usercreated" => "K�ytt�j� %s tehty salasanalle: %s.",
						"usertodelete" => "Haluatko varmasti poistaa k�ytt�j�n %s?", 
						"changinggrouplegend" => "Vaihdetaan ryhm��",
						"cannotchangegroup" => "Ei voi poistaa ryhm�st� k�ytt�j�� %s.", // %s is username
						"removeduserfromgroup" => "Poistettu k�ytt�j� %s mist� tahansa ryhm�st�.", // %s is username
						"changedgroupofuser" => "Vaihdettu k�ytt�j�n ryhm�� %s - %s.", // %s is username %s is group
						"changinggroupto" => "Vaihdetaan ryhm�� k�ytt�j�lle %s (nykyinen ryhm�: %s) :", // %s is username, %s is groupname
						"nogroupavailable" => "Ei ryhm�� avoinna",
						"none" => "Ei yht��n",
						"cantremoveownadmin" => "Et voi poistaa omia Adminin oikeuksiasi.",
						"usernotchanged" => "K�ytt�j�� ei voi tu vaihtaa.",
						"usernownoadmin" => "K�ytt�j� %s ei ole en�� Admin",
						"usernowadmin" => "K�ytt�j� %s on nyt Admin",
						"error" => "Error",
						"cannotsuspendyourself" => "Et voi suspendata itse�si.",
						"suspension" => "Suspension",
						"usernolongersuspended" => "K�ytt�j�t %s ei ole en�� suspended.", // %s is username
						"usernowsuspended" => "K�ytt�j� %s on nyt suspendettu. Syy: %s.", // %s is username, %s is reason
						"suspensionoflegend" => "Suspended: %s", // %s is username
						"suspend" => "Suspend",
						"group" => "Ryhm�",
						"traffic" => "Liikenne",
						"channels" => "Kanavat",
						"uptime" => "Online-aika",
						"client" => "Clientti",
						"level" => "K�ytt�j�taso",
						"susp." => "Susp.",
						"action" => "Action",
						"no" => "Ei",
						"yes" => "Kyll�",
						"virtualadministrator" => "Virtuaali Admin",
						"administrator" => "Admin",
						"user" => "K�ytt�j�",
						"killclient" => "Tapa clientti",
						"killbouncer" => "Tapa bounceri", 
						"log" => "Kirjaudu",
						"sendmessagebutton" => "L�het� viesti",
						"do" => "Tee",
						"createuserbutton" => "Lis�� k�ytt�j�",			
						"usercreatinglegend" => "K�ytt�j� tehty",
						"settingsforuser" => "Asetukset k�ytt�j�lle %s",
						"clearhost" => "Poista Host",	
						"clearhostlegend" => "K�ytt�j�n %s osoitteet poistettu.",
						"key" => "Avain:"
					);
		    $lang_hosts = array(
						"add" => "lis�t�",
						"remove" => "Poista",
						"hosts" => "hosts",
						"done" => "Tehty.",
						"action" => "Action"
					);

?>
