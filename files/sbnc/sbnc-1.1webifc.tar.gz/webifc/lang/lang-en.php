<?php
	/*****************************************************
	 *	English language file for webinterface		          *
	 ******************************************************/

	 // index.php
	 $lang_index = array(
 						"htmltitle" => "shroudBNC Webinterface",
						"title" => "shroudBNC Webinterface",
						"logoutlegend" => "Logout",
						"logoutlink" => "You are now logged out. Click <a href='login.php'>here</a> to log in again.",
						"user" => "User",
						"info" => "info",
						"settings" => "settings",
						"channels" => "channels",
						"log" => "log",
						"qauth" => "qauth",
						"contact" => "contact",
						"logout" => "logout",
						"vadmin" => "vadmin",
						"vlist" => "userlist",
						"vgroups" => "vgroups",
						"hosts" => "hosts",
						"admin" => "admin",
						"global" => "global",
						"userlist" => "userlist",
						"mainlog" => "mainlog",
						"language" => "language",
						"login" => "Login",
						"select" => "Select"
					);
						
	 
	 // info.php
	$lang_info = array(
						"accountinfo" => "Information about your account",
						"username" => "username",
						"currentnick" => "Current Nick",
						"uptime" => "Uptime",
						"client" => "Client",
						"none" => "None",
						"server" => "Server",
						"notconnected" => "Not connected",
						"traffic" => "Traffic",
						"in" => "In",
						"out" => "Out",
						"totaltraffic" => "Total traffic",
						"level" => "Level",
						"user" => "User",
						"administrator" => "Administrator",
						"virtualadministrator" => "Virtual Administrator"
						);
	
	// settings.php
	$lang_settings = array(
						"jump" => "Jump",
						"reconnect" => "Reconnecting...",
						"settings" => "Settings",
						"name" => "Name",
						"value" => "Value",
						"commit" => "Commit",
						"Password" => "Password",
						"Server" => "Server",
						"Port" => "Port",
						"Nick" => "Nick",
						"Realname" => "Realname",
						"Away-Nick" => "Away-nick",
						"Away-Reason" => "Away-reason",
						"Away-message" => "Away-message",
						"Vhost" => "Vhost",
						"set" => "Set",
						"settingschanged" => "Settings has been saved",
						"settingsonlyreconnect" => " (You will have to reconnect/JUMP for this to take effect)",
						"full" => "full",
						"notfull" => "not full"
						);
	
	// channels.php
	$lang_channels = array(
						"partlegend" => "Parting channel",
						"part" => "Parted channel %s", // %s == channel name
						"joinlegend" => "Joining channel",
						"join" => "Joined channel %s", // %s == channel name
						"channel" => "Channel",
						"chanmodes" => "Chanmodes",
						"topic" => "Topic",
						"users" => "Users",
						"channellegend" => "Channels",
						"command" => "Command",
						"totalchannels" => "Total channels: ",
						"notconnected" => "You are not connected.",
						"partbutton" => "Part",	
						"joinchannel" => "Join channel: ",
						"joinbutton" => "Join",			
						"key" => "key:"
					);
	
	// log.php
	$lang_log = array(
						"logerase" => "Log has been erased.",
						"erasebutton" => "Erase log",
						"loglegend" => "Private log",
						"logempty" => "Log is empty."
					);
					
	// qauth.php 
	$lang_qauth = array(
						"qauthlegend" => "Qauth",
						"done" => "done.",
						"note" => "Note: </b>Your password and username will be saved unencrypted! Enable it only if you agree with this and if you are really connected to QuakeNet!",
						"username" => "username:",
						"password" => "password:",
						"umodex" => "umode x:",
						"set" => "Set"
					);
					
	// contact.php
	$lang_contact = array(
						"email" => "email",
						"messagesendlegend" => "Message send",
						"messagesend" => "Following message was sent: ",
						"contactlegend" => "Contact",
						"ownemail" => "own email:*",
						"message" => "message: ",
						"send" => "Send",
						"notelogcheck" => "Check your log regulary (or emailaccount, if specified).",
						"optional" => "* optional"
					);

	// vgroups.php
	$lang_vgroups = array(
						"cantunadmin" => "You can't remove your own administrator privileges.",
						"virtualadministratorlegend" => "Virtual Administrator",
						"cantchangeuser" => "User could not be changed.",
						"nolongervadmin" => "User %s is no longer virtual admin.",
						"nowvadmin" => 	"User %s is now virtual admin.",
						"usersofgroup" => "Users of group %s", // %s is groupname
						"user" => "User",
						"level" => "Level",
						"virtualadministrator" => "Virtual Administrator",
						"newlimit" => "New limit for group %s set to: %s",  // first %s is groupname, second %s is the new limit
						"setnewlimitlegend" => "Set limit for group %s", // %s is groupname
						"setlimitlegend" => "New limit set",
						"set" => "Set",
						"creategrouplegend" => "Create Group",
						"groupcreated" => "Group %s was created. Additionally a user with the same name and the password %s was created.",
						"desc" => "Description",
						"name" => "Name",
						"limit" => "Limit",
						"value" => "Value",
						"createbutton" => "Create",
						"deletegrouplegend" => "Delete Group",
						"groupnotdeleted" => "Group could not be deleted: ",
						"groupwasdeleted" => "Group %s was removed.", // %s is groupname
						"deletegrouplegend" => "Delete Group %s", // %s is groupname
						"deleteconfirmation" => "Do you really want to delete group %s?", // %s is groupname
						"delete" => "delete",
						"group" => "Group",
						"groups" => "Groups",
						"users" => "Users",
						"action" => "Action",
						"setlimit" => "set limit",
						"do" => "do",
						"nogroups" => "There are no groups.",
						"creategroupbutton" => "Create group",
						"failedcreate" => "Failed to create group: ",			
						"failedlimitlegend" => "New limit not set",
						"newlimitfailed" => "Couldn't set new limit for %s" // %s is groupname
					);
					
	// global.php
	$lang_global = array(
						"globalnoticelegend" => "Global notice",
						"successfullysend" => "Sucessfully sent: ",
						"bncdisconnectedlegend" => "BNC disconnected",
						"bouncerkilled" => "The bouncer has been killed.",
						"dielegend" => "die",
						"dieconfirmation" => "Do you really want to kill the bnc?",
						"die" => "die",
						"TCLsuccessfullrehash" => "TCL was sucessfully rehashed.",
						"TCLlegend" => "TCL",
						"globallegend" => "Global",
						"globalnoticelegend" => "Global Notice",
						"send" => "send",
						"administration" => "Administration",
						"tclrehash" => "TCL rehash"
					);
					
	// mainlog.php
	$lang_mainlog = array(
						"mainloglegend" => "Main log",
						"logerased" => "Main log has been erased.", 
						"erasemainlogbutton" => "Erase main log"
					);
					
	// vlist.php
	$lang_vlist = array(
						"createuserlegend" => "Create User",
						"description" => "Description",
						"value" => "Value",
						"username" => "Username",
						"password" => "Password",
						"randomempty" => "random, if empty",
						"server" => "Server",
						"port" => "Port",
						"create" => "Create",
						"failedcreateuser" => "Failed to create user %s.", // %s is username
						"failedtocreateuserquota" => "Quota reached. You already have %s users.", // %s is number of users
						"usercreated" => "User %s was created with password: %s", // %s is username, %s is pass
						"deleteuserlegend" => "Delete user",
						"cantdeleteown" => "Stop trying to be funny. You can't delete yourself.",
						"usernotdeleted" => "User could not be deleted: ",
						"userdeleted" => "User %s was removed.", // %s is username
						"deletedconfirmation" => "Do you really want to delete user %s?", // %s is username
						"deletebutton" => "delete",
						"userslegend" => "Users",
						"user" => "User",
						"channels" => "Channels",
						"uptime" => "Uptime",
						"client" => "Client",
						"level" => "Level",
						"suspended" => "Suspended",
						"action" => "Action",
						"no" => "No",
						"yes" => "Yes",
						"virtualadministrator" => "Virtual Administrator",
						"delete" => "delete",
						"do" => "do",
						"createuserbutton" => "Create User",
						"done" => "done.",
						"resetpass" => "reset pass",
						"changepasswordlegend" => "Change password",
						"set" => "Set"
										
					);
					
		// language.php
		$lang_language = array(
						"langlegend" => "Language",
						"languageset" => "Language was set to %s.", // %s is language
						"currentlang" => "Your current language is: %s.", // %s is language
						"changeto" => "Change to: ",
						"set" => "Set",
						"none" => "None",
						"de" => "Deutsch",
						"en" => "English",
						"sw" => "Svenska",
						"nl" => "Nederlands",
						"fi" => "Suomen kieli",
						"dk" => "Dansk"
					);
					
					
		// userlist.php
		$lang_ulist = array(
						"users" => "Users",
						"createuser" => "Create User",
						"description" => "Description",
						"value" => "Value",
						"username" => "Username",
						"password" => "Password",
						"emptyforrandompass" => "Leave empty for random password",
						"server" => "Server",
						"port" => "Port",
						"ident" => "Ident",
						"emptyusernameident" => "if empty, ident is username",
						"create" => "Create",
						"isercreatinglegend" => "Creating user",
						"failedcreateuser" => "Failed to create user",
						"usercreate" => "User %s was created was password: %s.", // %s is username, %s is password
						"jump" => "Jump",
						"done" => "done." ,
						"successfullykilledclient" => "Successfully killed client connection of:",
						"usertokill" => "User to kill: ",
						"reason" => "reason: ",
						"kill" => "kill",
						"logerasedlegend" => "Erase log",
						"successfullyerasedlog" => "Successfully erased log of: ",
						"logof" => "Log of: ",
						"delete" => "delete",
						"successfullykilledserver" => "Successfully killed server connection of:",
						"usertodisconnect" => "User to disconnect: ",
						"disconnect" => "Disconnect",
						"messagesendlegend" => "Message send",
						"messagesend" => "Message to user %s send: %s.", // %s is username, %s is message
						"sendmessage" => "Send message",
						"send" => "Send",
						"chaninfoabout" => "Channel info about %s",
						"channel" => "Channel",
						"channelmodes" => "Channelmodes",
						"topic" => "Topic", 
						"users" => "Users",
						"channelparted" => "Channel parted",
						"successfullyjoinedchannel" => "%s successfully joined %s.", // %s is username, %s is channel
						"channeljoined" => "Channel joined",
						"successfullypartedchannel" => "%s successfully parted %s.",  // %s is username, %s is channel
						"part" => "Part",
						"user" => "User",
						"join" => "Join",
						"modes" => "Modes",
						"command" => "Command",
						"totalnumberofchannels" => "Total number of channels: ",
						"notconnectedlegend" => "Not connected",
						"notconnected" => "This user is not connected.",
						"set" => "Set",
						"name" => "Name",
						"value" => "Value",
						"lock" => "Lock",
						"commit" => "Commit",
						"not connected" => "Not connected.",
						"jump" => "Jump",
						"Password" => "Password",
						"Server" => "Server",
						"Port" => "Port",
						"Nick" => "Nick",
						"Realname" => "Realname",
						"Away-Nick" => "Away-Nick",
						"Away-Reason" => "Away-Reason",
						"Away-message" => "Away-Message",
						"Vhost" => "Vhost",
						"Ident" => "Ident",
						"cantdeleteyourself" => "Stop trying to be funny. You can't delete yourself.",
						"userdeletedlegend" => "User deleted",
						"userdeleted" => "User %s was removed.", // %s is username
						"usertodeletelegend" => "User to delete: %s",  // %s is username
						"usercreated" => "User %s has been created with password: %s.",
						"usertodelete" => "Do you really want to delete %s?", 
						"changinggrouplegend" => "Changing Group",
						"cannotchangegroup" => "Cannot change group of user %s.", // %s is username
						"removeduserfromgroup" => "Removed user %s from any group.", // %s is username
						"changedgroupofuser" => "Changed group of user %s to %s.", // %s is username %s is group
						"changinggroupto" => "Changing group of user %s (current group: %s) to:", // %s is username, %s is groupname
						"nogroupavailable" => "No group available",
						"none" => "none",
						"cantremoveownadmin" => "You can't remove your own administrator privileges.",
						"usernotchanged" => "User could not be changed.",
						"usernownoadmin" => "User %s is no longer admin",
						"usernowadmin" => "User %s is now admin",
						"error" => "Error",
						"cannotsuspendyourself" => "You cannot suspend yourself.",
						"suspension" => "Suspension",
						"usernolongersuspended" => "User %s is no longer suspended.", // %s is username
						"usernowsuspended" => "User %s is now suspended. Reason: %s.", // %s is username, %s is reason
						"suspensionoflegend" => "Suspension of: %s", // %s is username
						"suspend" => "Suspend",
						"group" => "Group ",
						"traffic" => "Traffic",
						"channels" => "Channels",
						"uptime" => "Uptime",
						"client" => "Client",
						"level" => "Level",
						"susp." => "Susp.",
						"action" => "Action",
						"no" => "No",
						"yes" => "Yes",
						"virtualadministrator" => "Virtual Administrator",
						"administrator" => "Administrator",
						"user" => "User",
						"killclient" => "kill client",
						"killbouncer" => "kill bouncer", 
						"log" => "log",
						"sendmessagebutton" => "send message",
						"do" => "do",
						"createuserbutton" => "Create User",			
						"usercreatinglegend" => "User created",
						"settingsforuser" => "Settings for user %s",
						"emptylog" => "Log is empty.",
						"clearhost" => "Clear hosts",
						"clearhostlegend" => "Host cleared for %s.",
						"key" => "Key:"
						
					);
		    $lang_hosts = array(
						"hosts" => "Hosts",
						"remove" => "remove",
						"add" => "add",
						"done" => "done.",
						"action" => "Action"
					);
						

?>
