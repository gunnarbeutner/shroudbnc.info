<?php
	/*******************************************************
	 *	Swedish language file for webinterface, translated by Sharkey   *
	 *******************************************************/

	 // index.php
	 $lang_index = array(
 						"htmltitle" => "sBNC Webbgr�nssnitt",
						"title" => "sBNC Webbgr�nssnitt",
						"logoutlegend" => "Logga ut",
						"logoutlink" => "Du �r nu utloggad. Klicka <a href='login.php'>h�r</a> f�r att logga in igen.",
						"user" => "Anv�ndare",
						"info" => "info",
						"settings" => "inst�llningar",
						"channels" => "kanaler",
						"log" => "logg",
						"qauth" => "qauth",
						"contact" => "kontakt",
						"logout" => "logga ut",
						"vadmin" => "vadmin",
						"hosts" => "hosts",
						"vlist" => "vlista",
						"vgroups" => "vgrupper",
						"admin" => "administrat�r",
						"global" => "global",
						"userlist" => "anv�ndarlista",
						"mainlog" => "huvudlogg",
						"language" => "spr�k",
						"login" => "Logga in",
						"select" => "vaelja ut"
					);
						
	 
	 // info.php
	$lang_info = array(
						"accountinfo" => "Information om ditt konto",
						"username" => "anv�ndarnamn",
						"currentnick" => "Aktuellt Smeknamn",
						"uptime" => "Uptime",
						"client" => "Klient",
						"none" => "Ingen",
						"server" => "Server",
						"notconnected" => "Inte ansluten",
						"traffic" => "Trafik",
						"in" => "In",
						"out" => "Ut",
						"totaltraffic" => "Total trafik",
						"level" => "Niv�",
						"virtualadministrator" => "Virtuell Administratoer",
						"administrator" => "Administrateoer",
						"user" => "Anvaendare"
																		
					);
	
	// settings.php
	$lang_settings = array(
						"jump" => "Starta om",
						"reconnect" => "�teransluter...",
						"settings" => "Inst�llningar",
						"name" => "Namn",
						"value" => "V�rde",
						"commit" => "�ndra",
						"Password" => "L�senord",
						"Server" => "Server",
						"Port" => "port",
						"Nick" => "Smeknamn",
						"Realname" => "Riktigt namn",
						"Away-Nick" => "Away-smeknamn",
						"Away-Reason" => "Away-anledning",
						"Away-message" => "Away-meddelande",
						"Vhost" => "Vhost",
						"set" => "�ndra",
						"settingschanged" => "Instllningarna har sparats.",
						"settingsonlyreconnect" => "Du m�ste starta om f�r att denna �ndring ska verkst�llas",
						"full" => "fullt",
						"notfull" => "ledigt"
						);
	
	// channels.php
	$lang_channels = array(
						"partlegend" => "L�mnar kanalen",
						"part" => "L�mnade kanalen: %s", // %s == channel name
						"joinlegend" => "Kliver in i kanalen",
						"join" => "Klev in i kanalen: %s", // %s == channel name
						"channel" => "Kanal",
						"chanmodes" => "Kanalmodes",
						"topic" => "�mne",
						"users" => "Anv�ndare",
						"channellegend" => "Kanaler",
						"command" => "Kommando",
						"totalchannels" => "Antal kanaler: ",
						"notconnected" => "Du �r inte ansluten.",
						"partbutton" => "L�mna",	
						"joinchannel" => "Kliv in i kanal: ",
						"joinbutton" => "Kliv in",
						"key" => "Nyckel:"
					);
	
	// log.php
	$lang_log = array(
						"logerase" => "Loggen har rensats.",
						"erasebutton" => "Rensa logg",
						"loglegend" => "Privat logg",
						"logempty" => "Loggen aer tom."
					);
					
	// qauth.php 
	$lang_qauth = array(
						"qauthlegend" => "Q-auth",
						"done" => "klar.",
						"note" => "OBS: </b>Ditt l�senord och anv�ndarnamn kommer sparas �ppet! Markera det endast om du godk�nner detta och om du verkligen �r ansluten till QuakeNet!",
						"username" => "anv�ndarnamn:",
						"password" => "l�senord:",
						"umodex" => "umode x:",
						"set" => "Spara"
					);
					
	// contact.php
	$lang_contact = array(
						"email" => "e-mail",
						"messagesendlegend" => "Meddelande skickat",
						"messagesend" => "F�ljande meddelande skickades: ",
						"contactlegend" => "Kontakt",
						"ownemail" => "egen e-mail:*",
						"message" => "meddelande: ",
						"send" => "Skicka",
						"notelogcheck" => "Kontrollera din logg regelbundet (eller e-mailkonto, om angiven).",
						"optional" => "* frivilligt"
					);

	// vgroups.php
	$lang_vgroups = array(
						"cantunadmin" => "Du kan inte ta bort din egen administrat�rsstatus.",
						"virtualadministratorlegend" => "Virtuell Administrat�r",
						"cantchangeuser" => "Anv�ndaren kunde inte �ndras.",
						"nolongervadmin" => "Anv�ndaren %s �r inte l�ngre en virtuell administrat�r.",
						"nowvadmin" => 	"Anv�ndaren %s �r nu en virtuell administrat�r.",
						"usersofgroup" => "Anv�ndare i gruppen %s", // %s is groupname
						"user" => "Anv�ndare",
						"level" => "Niv�",
						"virtualadministrator" => "Virtuell Administrat�r",
						"newlimit" => "Ny gr�ns f�r grupp %s �ndrad till: %s",  // first %s is groupname, second %s is the new limit
						"setnewlimitlegend" => "�ndra gr�ns f�r gruppen %s", // %s is groupname
						"setlimitlegend" => "Ny gr�ns satt",
						"set" => "�ndra",
						"creategrouplegend" => "Skapa Grupp",
						"groupcreated" => "Gruppen %s skapades. Ytterligare skapades en anv�ndare med samma namn och l�senordet %s.",
						"desc" => "Beskrivning",
						"name" => "Namn",
						"limit" => "Gr�ns",
						"value" => "Vaerde",
						"createbutton" => "Skapa",
						"deletegrouplegend" => "Ta bort grupp",
						"groupnotdeleted" => "Gruppen kunde inte tas bort: ",
						"groupwasdeleted" => "Gruppen %s har tagits bort.", // %s is groupname
						"deletegrouplegend" => "Ta bort grupp: %s", // %s is groupname
						"deleteconfirmation" => "Vill du verkligen ta bort gruppen %s?", // %s is groupname
						"delete" => "ta bort",
						"group" => "Grupp",
						"groups" => "Grupper",
						"users" => "Anv�ndare",
						"action" => "�tg�rd",
						"setlimit" => "�ndra gr�ns",
						"do" => "forts�tt",
						"nogroups" => "Det finns inga grupper.",
						"creategroupbutton" => "Skapa grupp",
						"failedcreate" => "Misslyckades att skapa gruppen: ",			
						"failedlimitlegend" => "Ny gr�ns har inte �ndrats",
						"newlimitfailed" => "Kunde inte �ndra gr�nsen f�r gruppen %s" // %s is groupname
					);
					
	// global.php
	$lang_global = array(
						"globalnoticelegend" => "Globalt meddelande",
						"successfullysend" => "Skickat: ",
						"bncdisconnectedlegend" => "BNC bortkopplad",
						"bouncerkilled" => "Bouncern har kopplats ner.",
						"dielegend" => "koppla ner",
						"dieconfirmation" => "Vill du verkligen koppla bort BNCn?",
						"die" => "koppla ner",
						"TCLsuccessfullrehash" => "TCL har startats om korrekt.",
						"TCLlegend" => "TCL",
						"globallegend" => "Global",
						"globalnoticelegend" => "Globalt meddelande",
						"send" => "skicka",
						"administration" => "Administration",
						"tclrehash" => "TCL omstart"
					);
					
	// mainlog.php
	$lang_mainlog = array(
						"mainloglegend" => "Huvudlogg",
						"logerased" => "Huvudloggen har rensats.", 
						"erasemainlogbutton" => "Rensa huvudloggen"
					);
					
	// vlist.php
	$lang_vlist = array(
						"createuserlegend" => "Skapa anv�ndare",
						"description" => "Beskrivning",
						"value" => "V�rde",
						"username" => "Anv�ndarnamn",
						"password" => "L�senord",
						"randomempty" => "Laemna tomt foer slumpat loesenord",
						"server" => "Server",
						"port" => "Port",
						"create" => "Skapa",
						"failedcreateuser" => "Misslyckades att skapa anv�ndaren %s.", // %s is username
						"failedtocreateuserquota" => "Maxantalet n�tt. Du har redan %s anv�ndare.", // %s is number of users
						"usercreated" => "Anv�ndaren %s skapades.", // %s is username
						"deleteuserlegend" => "Ta bort anv�ndare",
						"cantdeleteown" => "F�rs�k inte vara rolig, du kan inte ta bort dig sj�lv.",
						"usernotdeleted" => "Anv�ndaren kunde inte tas bort: ",
						"userdeleted" => "Anv�ndaren %s har tagits bort.", // %s is username
						"deletedconfirmation" => "Vill du verkligen ta bort anv�ndaren %s?", // %s is username
						"deletebutton" => "ta bort",
						"userslegend" => "Anv�ndare",
						"user" => "Anv�ndare",
						"channels" => "Kanaler",
						"uptime" => "Uptime",
						"client" => "Klient",
						"level" => "Niv�",
						"suspended" => "Avst�ngd",
						"action" => "�tg�rd",
						"no" => "Nej",
						"yes" => "Ja",
						"virtualadministrator" => "Virtuell Administrat�r",
						"delete" => "ta bort",
						"do" => "vidare",
						"createuserbutton" => "Skapa anv�ndare",
						"set" => "Aendra",
						"done" => "klar.",
						"resetpass" => "aendra loesen",
						"changepasswordlegend" => "aendra loesen"
					);
					
		// language.php
		$lang_language = array(
						"langlegend" => "Spr�k",
						"languageset" => "Spr�ket har �ndrats till %s.", // %s is language
						"currentlang" => "Ditt nuvarande spr�k �r %s.", // %s is language
						"changeto" => "�ndra till: ",
						"set" => "�ndra",
						"none" => "Ingen",
						"de" => "Deutsch",
						"en" => "English",
						"sw" => "Svenska",
						"nl" => "Nederlands",
						"fi" => "Suomen kieli",
						"dk" => "Dansk"
					);
					
					
		// userlist.php
		$lang_ulist = array(
						"users" => "Anv�ndare",
						"createuser" => "Skapa anv�ndare",
						"description" => "Beskrivning",
						"value" => "V�rde",
						"username" => "Anv�ndarnamn",
						"password" => "L�senord",
						"emptyforrandompass" => "L�mna tomt f�r slumpat l�senord",
						"server" => "Server",
						"port" => "Port",
						"ident" => "Ident",
						"emptyusernameident" => "om tomt; ident blir anv�ndarnamnet",
						"create" => "Skapa",
						"isercreatinglegend" => "Skapar anv�ndare",
						"failedcreateuser" => "Misslyckades att skapa anv�ndare.",
						"usercreate" => "Anv�ndaren %s skapades med l�senordet: %s.", // %s is username, %s is password
						"jump" => "Starta om",
						"done" => "klar." ,
						"successfullykilledclient" => "Korrekt nedkoppling av klienten:",
						"usertokill" => "Anv�ndare att koppla ner: ",
						"reason" => "anledning: ",
						"kill" => "koppla ner",
						"logerasedlegend" => "Rensa logg",
						"successfullyerasedlog" => "Korrekt rensad logg: ",
						"logof" => "Logg av: ",
						"delete" => "ta bort",
						"successfullykilledserver" => "Lyckad nedkopplad anslutning av:",
						"usertodisconnect" => "Anv�ndare att koppla ner: ",
						"disconnect" => "Koppla ner",
						"messagesendlegend" => "Meddelande skickat",
						"messagesend" => "Meddelande till anv�ndaren %s skickat: %s.", // %s is username, %s is message
						"sendmessage" => "Skicka meddelande",
						"send" => "Skicka",
						"chaninfoabout" => "Kanalinfo om %s",
						"channel" => "Kanal",
						"channelmodes" => "Kanalmodes",
						"topic" => "�mne", 
						"users" => "Anv�ndare",
						"channelparted" => "Kanal l�mnad",
						"successfullyjoinedchannel" => "%s lyckades g� in i %s.", // %s is username, %s is channel
						"channeljoined" => "G�tt in i kanalen",
						"successfullypartedchannel" => "%s l�mnade %s.",  // %s is username, %s is channel
						"part" => "L�mna",
						"user" => "Anv�ndare",
						"join" => "G� in",
						"modes" => "Modes",
						"command" => "Kommando",
						"totalnumberofchannels" => "Antal kanaler: ",
						"notconnectedlegend" => "Inte ansluten",
						"notconnected" => "Den h�r anv�ndaren �r inte ansluten."
,
						"set" => "�ndra",
						"name" => "Namn",
						"value" => "V�rde",
						"lock" => "L�s",
						"commit" => "�ndra",
						"not connected" => "Inte ansluten.",
						"jump" => "Starta om",
						"Password" => "L�senord",
						"Server" => "Server",
						"Port" => "Port",
						"Nick" => "Smeknamn",
						"Realname" => "Riktigt namn",
						"Away-Nick" => "Away-smeknamn",
						"Away-Reason" => "Away-anledning",
						"Away-message" => "Away-meddelande",
						"Vhost" => "Vhost",
						"Ident" => "Ident",
						"cantdeleteyourself" => "F�rs�k inte vara rolig, du kan inte ta bort dig sj�lv.",
						"userdeletedlegend" => "Anv�ndare borttagen",
						"userdeleted" => "Anv�ndaren %s �r borttagen.", // %s is username
						"usertodeletelegend" => "Anv�ndare att ta bort: %s",  // %s is username
						"usercreated" => "Anv�ndaren %s har skapats med l�senordet: %s.",
						"usertodelete" => "Vill du verkligen ta bort %s?", 
						"changinggrouplegend" => "Byt grupp",
						"cannotchangegroup" => "Kan inte byta grupp p� %s.", // %s is username
						"removeduserfromgroup" => "Anv�ndaren %s borttagen fr�n grupp.", // %s is username
						"changedgroupofuser" => "�ndrade grupp f�r anv�ndaren %s till %s.", // %s is username %s is group
						"changinggroupto" => "�ndrar grupp f�r anv�ndaren %s (nuvarande grupp: %s) till:", // %s is username, %s is groupname
						"nogroupavailable" => "Ingen grupp tillg�nglig",
						"none" => "ingen",
						"admin" => "Administrat�r", 
						"cantremoveownadmin" => "Du kan inte ta bort din egen administrat�rsstatus.",
						"usernotchanged" => "Anv�ndaren kunde inte �ndras.",
						"usernownoadmin" => "Anv�ndaren %s �r inte l�ngre administrat�r",
						"usernowadmin" => "Anv�ndaren %s �r nu administrat�r",
						"error" => "Felmeddelande",
						"cannotsuspendyourself" => "Du kan inte suspendera dig sj�lv.",
						"suspension" => "Suspendera",
						"usernolongersuspended" => "Anv�ndaren %s �r inte l�ngre suspenderad.", // %s is username
						"usernowsuspended" => "Anv�ndaren %s �r nu suspenderad. Anledning: %s.", // %s is username, %s is reason
						"suspensionoflegend" => "Suspendering av: %s", // %s is username
						"suspend" => "Suspendera",
						"group" => "Grupp: ",
						"traffic" => "Trafik",
						"channels" => "Kanaler",
						"uptime" => "Uptime",
						"client" => "Klient",
						"level" => "Niv�",
						"susp." => "Susp.",
						"action" => "�tg�rd",
						"no" => "Nej",
						"yes" => "Ja",
						"virtualadministrator" => "Virtuell Administrat�r",
						"administrator" => "Administrat�r",
						"user" => "Anv�ndare",
						"killclient" => "koppla ner klient",
						"killbouncer" => "koppla ner bouncer", 
						"log" => "logg",
						"channels" => "kanaler",
						"sendmessagebutton" => "skicka meddelande",
						"do" => "vidare",
						"createuserbutton" => "Skapa anv�ndare",			
						"usercreatinglegend" => "Anv�ndare skapad",
						"settingsforuser" => "Inst�llningar f�r anv�ndaren: %s",
						"emptylog" => "Loggen aer tom.",
						"clearhost" => "ta bort hosts",
						"clearhostlegend" => "Hosts av %s tomda",
						"key" => "Nyckel:"
					);
			$lang_hosts = array(
						"add" => "lägg till",
						"remove" => "ta bort",
						"hosts" => "hosts",
						"done" => "klar.",
						"action" => "�tg�rd"
					);
?>
