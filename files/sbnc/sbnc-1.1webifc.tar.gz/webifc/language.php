<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();

printf('<fieldset><legend>%s</legend>',$lang_language['langlegend']);

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "set") {
	sbnc_command('setlanguage '.$_REQUEST['lang']);
	printf($lang_language['languageset'].'<br />', $_REQUEST['lang']);
}

$lang = sbnc_command('tag lang');
if ($lang == "") { $lang = 'none'; }
printf($lang_language['currentlang'].'<br /><br />', $lang_language[$lang]);
printf('%s', $lang_language['changeto']);
printf('<form method="POST" action="index.php">
		<input type="hidden" name="p" value="language">
		<input type="hidden" name="do" value="set">
		<table><tr><td>
		<select name="lang">');
$dir = "lang/"
;
if (is_dir($dir)) {
   if ($dh = opendir($dir)) {
       while (($file = readdir($dh)) !== false) {
			$lang2 = substr($file, 5, 2);
			if ($lang2 != "") {
			    echo '<option value="'.$lang2.'" ';
			    if ($lang == $lang2) { echo 'selected'; }
			    echo '>'.$lang_language[$lang2].'</option>';
			}
       }
       closedir($dh);
   }
}
printf('</select></td><td><input type="submit" name="set" value="%s">',$lang_language['set']);
printf('</td></tr></table></form></fieldset>');

?>