<?php

// name and ip port of all connections this webinterface is supposed to be used for

// DO NOT CHANGE THE _PORT_ UNLESS YOU KNOW WHAT YOU'RE DOING.

$connections = array(
    "sBNC" => "127.0.0.1 8090"
);

// default language file (has to exist!)
$defaultlanguagefile = "lang/lang-en.php";

$ifacetheme = 'style/default/style.css';

?>
