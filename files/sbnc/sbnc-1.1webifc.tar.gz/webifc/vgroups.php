<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
sbnc_guardadmin();

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "users") {
    if (isset($_REQUEST['vadmin']) && $_REQUEST['vadmin']) {
	printf('<fieldset><legend>%s</legend>',$lang_vgroups['virtualadministratorlegend']);
	if (strcasecmp(sbnc_account(), $_REQUEST['user']) == 0) {
	    printf('%s',$lang_vgroups['cantunadmin']);
	} else {
	    if (isset($_REQUEST['was']) && $_REQUEST['was'] == 'yes') {
		$result = sbnc_command('vunadmin '.$_REQUEST['user']);
	    } else {
		$result = sbnc_command('vadmin '.$_REQUEST['user']);
	    }
	    if ($result) {
		 printf('%s',$lang_vgroups['cantchangeuser']);
	    } else {
	        if (isset($_REQUEST['was']) && $_REQUEST['was'] == 'yes') {
				printf($lang_vgroups['nolongervadmin'],htmlentities($_REQUEST['user']));
			} else {
				printf($lang_vgroups['nowvadmin'], htmlentities($_REQUEST['user']));
	        }
	    }
	}
	printf('</fieldset></br>');
    }
									    
    printf('<fieldset><legend>'.$lang_vgroups['usersofgroup'].'</legend>',$_REQUEST['group']);
    printf('<table><tr><td><b>%s</b></td><td><b>%s</b></td></tr>',$lang_vgroups['user'],$lang_vgroups['level']);
    $users = explode(" ",sbnc_command('vgroupusers '.$_REQUEST['group']));
    $vadmins = array();
    $vusers = array();
    $users2 = array();
    foreach ($users as $user) {
	if (sbnc_command('visadmin '.$user)) { array_push($vadmins, $user); }
	else { array_push($vusers, $user); }
    }
    foreach ($vadmins as $user) {
	array_push($users2, $user);
    }
    foreach ($vusers as $user) {
	array_push($users2, $user);
    }
    foreach ($users2 as $user) {
	echo '<tr><td>';
	echo $user;
	echo '</td><td>';
	if (sbnc_command('visadmin '.$user)) {
	    printf('<a href="index.php?p=vgroups&do=users&user='.$user.'&group='.$_REQUEST['group'].'&vadmin=true&was=yes">%s</a>',$lang_vgroups['virtualadministrator']);
	} else {
	    printf('<a href="index.php?p=vgroups&do=users&user='.$user.'&group='.$_REQUEST['group'].'&vadmin=true&was=no">%s</a>',$lang_vgroups['user']);
	}
	printf('</td></tr>');
    }
    printf('</table></fieldset><br />');
}

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "setlimit") {
    if (isset($_REQUEST['newlimit'])) {
        $ret = explode(" ",sbnc_command('vsetlimit '.$_REQUEST['group'].' '.$_REQUEST['newlimit']));
	if ($ret[0] != "-1") {
	    printf('<fieldset><legend>%s</legend>',$lang_vgroups['setlimitlegend']);
	    printf($lang_vgroups['newlimit'],$_REQUEST['group'],$_REQUEST['newlimit']);
	    printf('</fieldset><br />');
	} else {
	    printf('<fieldset><legend>%s</legend>',$lang_vgroups['failedlimitlegend']);
	    printf($lang_vgroups['newlimitfailed'],$_REQUEST['group']);
	    printf('</fieldset><br />');
	}
    } else {
	printf('<fieldset><legend>'.$lang_vgroups['setnewlimitlegend'].'</legend>',$_REQUEST['group']);
    printf('
	    <form method="POST" action="index.php">
	    <input type="hidden" name="p" value="vgroups">
	    <input type="hidden" name="group" value="'.$_REQUEST['group'].'">
	    <input type="hidden" name="setlimit" value="true">
	    <input type="hidden" name="do" value="setlimit">
	    <input name="newlimit">
	    <input type="submit" value="%s">
	    </form>
	    ',$lang_vgroups['set']);
	printf('</fieldset><br />');
    }
}
if (isset($_REQUEST['do']) && $_REQUEST['do'] == "create") {
    if (isset($_REQUEST['create2']) && isset($_REQUEST['group']) && isset($_REQUEST['limit'])) {
	$result = explode(' ', sbnc_command('vaddgroup ' . $_REQUEST['group'] . ' ' . $_REQUEST['limit']), 2);
	printf('<fieldset><legend>%s</legend>',$lang_vgroups['creategrouplegend']);
	if ($result[0] == -1) {
	    printf('%s %s', $lang_vgroups['failedcreate'], $result[1]);
	} else {
		printf($lang_vgroups['groupcreated'], htmlentities($_REQUEST['group']), $result[1]);

	}
	printf('</fieldset><br />');
    } else {
	printf('
	    <fieldset><legend>%s</legend>
	    <form method="post" action="index.php">
	    <input type="hidden" name="p" value="vgroups" />
	    <input type="hidden" name="do" value="create" />
	    <input type="hidden" name="create2" value="" />
	    <table>
		<tr><td align="right"><b>%s</b></td><td><b>%s</b></td></tr>
		<tr><td align="right"><b>%s</b></td><td><input name="group" /></td></tr>
		<tr><td align="right"><b>%s</b></td><td><input name="limit" /></td></tr>
	    </table>
	    <br>
	    <input type="submit" value="%s" />
	    </form></fieldset>
<br />
	',$lang_vgroups['creategrouplegend'],$lang_vgroups['desc'],$lang_vgroups['value'], $lang_vgroups['name'],$lang_vgroups['limit'],$lang_vgroups['createbutton']);
    }
}


if (isset($_REQUEST['do']) && $_REQUEST['do'] == "delete") {
    if (isset($_REQUEST['confirmation'])) {
	$result = explode(' ', sbnc_command('vdelgroup ' . $_REQUEST['group']), 2);

    	printf('<fieldset><legend>'.$lang_vgroups['deletegrouplegend'].'</legend>',$_REQUEST['group']);
	if ($result[0] == -1) {
    	    printf('%s %s', $lang_vgroups['groupnotdeleted'], $result[1]);
	} else {
	    printf($lang_vgroups['groupwasdeleted'], htmlentities($_REQUEST['group']));
	}
	printf('</fieldset><br />');
    } else {
	printf('<fieldset><legend>'.$lang_vgroups['deletegrouplegend'].'</legend>',$_REQUEST['group']);
	printf(
		$lang_vgroups['deleteconfirmation'].'
	    <form method="POST" action="index.php">
	    <input type="hidden" name="p" value="vgroups">
	    <input type="hidden" name="group" value="'.$_REQUEST['group'].'">
	    <input type="hidden" name="confirmation" value="true">
	    <input type="hidden" name="do" value="delete">
	    <input type="submit" name="Delete" value="%s">
	    </form>
	    ',$_REQUEST['group'],$lang_vgroups['delete']);
	printf('</fieldset><br />');
    }
}

$groups_str = sbnc_command('vgroups');

$groups = explode(' ', $groups_str);

if ($groups_str != "") {

	printf('<fieldset><legend>%s</legend><table><tr><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td></tr>',$lang_vgroups['groups'], $lang_vgroups['group'], $lang_vgroups['users'], $lang_vgroups['action']);

foreach ($groups as $group) {
  printf('<tr>');
  printf('<td>' . $group . '</td>');
  $number = count(explode(" ",sbnc_command('vgroupusers '.$group)));
  printf('<td>' . $number . ' / '. sbnc_command('vgetlimit ' . $group) . '</td>');
  printf('
	<td>
	    <table><tr><td>
	    <form method="post" action="index.php">
	    <input type="hidden" name="p" value="vgroups">
	    <input type="hidden" name="group" value="'.$group.'">
	    <select name="do">
	    <option value="delete">%s</option>
	    <option value="setlimit">%s</option>
	    <option value="users">%s</options>
	    </select>
	    </td><td>
	    <input type="submit" value="%s">
	    </td></tr></table>
	    </form>
	</td>
	',$lang_vgroups['delete'], $lang_vgroups['setlimit'], $lang_vgroups['users'], $lang_vgroups['do']);
													
  echo '</tr>';
}

printf('</table>');

} else {
  printf('<fieldset><legend>%s</legend>%s<br>',$lang_vgroups['group'], $lang_vgroups['nogroups']);
}

printf('<br><form><input TYPE="button" onClick="parent.location=\'index.php?p=vgroups&do=create\'" value="%s"></form></fieldset>',$lang_vgroups['creategroupbutton']);

?>