<?

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();

if (isset($_REQUEST['name'])) {
    $name = $_REQUEST['name'];

    if (isset($_REQUEST['value'])) {
      $value = $_REQUEST['value'];
    } else {
      $value = '';
    }
    
    switch ($name) {
	case 'qauthusername':
	    sbnc_command('qsetuser ' . $value);
	    break;
	case 'qauthpassword':
	    sbnc_command('qsetpass ' . $value);
	    break;
	case 'qauthenable':
	    if (!strcasecmp($value, 'enabled')) { sbnc_command("qsetx 1"); }
	    else { sbnc_command("qsetx 0"); }
	    break;
    }
    printf('<fieldset><legend>%s</legend>%s</fieldset><br />',$lang_qauth['qauthlegend'],$lang_qauth['done']);
} 
printf('<fieldset><legend>%s</legend><br />',$lang_qauth['qauthlegend']);
printf('<b>%s<br /><br />',$lang_qauth['note']);
printf('	
    <table>
    <form method="POST" action="index.php">
    <input type="hidden" name="p" value="qauth">
    <input type="hidden" name="name" value="qauthusername">
    <tr><td><label>%s</label></td><td><input name="value" ',$lang_qauth['username']);
if (sbnc_command("qgetuser")) { printf('value="%s"',sbnc_command("qgetuser")); }
printf('></td><td><input type="submit" value="%s"></tr>
    </form>
    <form method="POST" action="index.php">
    <input type="hidden" name="p" value="qauth">
    <input type="hidden" name="name" value="qauthpassword">
    <tr><td><label>%s</label></td><td><input name="value" type="password" ',$lang_qauth['set'],$lang_qauth['password']);
if (sbnc_command("qhaspass")) { printf('value="*******" '); }
printf('name="qauthpassword"></td><td><input type="submit" value="%s"></tr>
    </form>
    <form method="POST" action="index.php">
    <input type="hidden" name="p" value="qauth">
    <input type="hidden" name="name" value="qauthenable">
    <tr><td><label>%s</label></td><td><input type="checkbox" value="enabled" name="value"',$lang_qauth['set'],$lang_qauth['umodex']);
if (sbnc_command("qgetx")) { printf("checked"); }
printf('
    ></td><td><input type="submit" value="%s"></tr>
    </form>
    </table>',$lang_qauth['set']);

/**** DISCUSSION NEEDED ****
printf('</fieldset>');
printf('<fieldset><legend>Invite</legend>');
printf('<fieldset><legend>Q</legend><br />');
printf('<form action="index.php" method="POST"><input type="hidden" name="p" value="qauth">
	<input type="hidden" name="do" value="add"><input name="channel">
	<input type="submit" name="add" value="add"></form>');
$qinvite = explode(" ",sbnc_command('getinvite Q'));
printf('<table width="80%%"><tr><td width="20%%">Channel</td><td>Action</td></tr>');
foreach ($qinvite as $channel) {
    printf('<tr><td>%s</td><td><form action="index.php" method="POST"><input type="hidden" name="p" value="qauth">
			    <input type="hidden" name="do" value="del">
			    <input type="hidden" name="bot" value="Q">
			    <input type="hidden" name="channel" value="%s">
			    <input type="submit" value="del" name="del"></form></td></tr>',$channel, $channel);
}
printf('</table></fieldset>');
****** END OF QAUTH INVITE *****/
?>
		