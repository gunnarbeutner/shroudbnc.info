<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
sbnc_guardvirtual();

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "create") {
    if (!isset($_REQUEST['create2'])) {
    printf('
	<fieldset><legend>%s</legend>
	<form method="post" action="index.php">
	<input type="hidden" name="p" value="vlist" />
	<input type="hidden" name="create2" value="" />
	<input type="hidden" name="do" value="create">
	<table>
	    <tr><td align="left"><b>%s</b></td><td><b>%s</b></td></tr>
	    <tr><td align="left"><b>%s</b></td><td><input name="user" /></td></tr>
	    <tr><td align="left"><b>%s <div style="font-size:7pt;">%s</div></b></td><td><input type="password" name="pass" /></td></tr>
	</table>
	<br>
	<input type="submit" value="%s" />
	    </form/></fieldset>',$lang_vlist['createuserlegend'], $lang_vlist['description'], $lang_vlist['value'], $lang_vlist['username'], $lang_vlist['password'], $lang_vlist['randomempty'], $lang_vlist['server'], $lang_vlist['port'], $lang_vlist['create']);
      return;
  } else {
    if (isset($_REQUEST['user'])) {
	if (strlen($_REQUEST['pass']) > 0) { $pass = $_REQUEST['pass']; }
	else {
	    $newpass = "";
	    for($i=0;$i<8;$i++) {
		$num = rand(48,122);
	        if (($num > 46 && $num < 58) || ($num > 64 && $num < 91) || ($num > 96 && $num < 123)) {
	            $newpass .= chr($num);
	        } else {
		    $i--;
		}
	    }
	    $pass = $newpass;
	}
	$result = explode(' ', sbnc_command('vadduser ' . $_REQUEST['user'] . ' ' . $pass), 2);

  	printf('<fieldset><legend>%s</legend>',$lang_vlist['createuserlegend']);
	if ($result[0] == -1) {
	    printf($lang_vlist['failedcreateuser'], $result[1]);
	} else if ($result[0] == -2) {
	    printf($lang_vlist['failedtocreateuserquota'], $result[1]);
	} else {
	    printf($lang_vlist['usercreated'], htmlentities($_REQUEST['user']), $pass);
	}
	printf('</fieldset><br />');
    }
  }
}

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "resetpass") {
    printf('<fieldset><legend>%s</legend>', $lang_vlist['changepasswordlegend']);
    if (isset($_REQUEST['passconfirmation'])) {
	sbnc_command('vresetpass '.$_REQUEST['user'].' '.$_REQUEST['password']);
	printf('%s',$lang_vlist['done']);
    } else {
	printf('
	    <form method="POST" action="index.php">
	    <input type="hidden" name="p" value="vlist">
	    <input type="hidden" name="user" value="'.$_REQUEST['user'].'">
	    <input type="hidden" name="do" value="resetpass">
	    <input type="hidden" name="passconfirmation" value="true">
	    <input name="password" type="password">
	    <input type="submit" value="%s" name="resetpass"></form>
	    ', $lang_vlist['set']);
    }
    printf('</fieldset><br />');
}

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "delete") {
  printf('<fieldset><legend>%s</legend>',$lang_vlist['deleteuserlegend']);
  if (isset($_REQUEST['confirmation'])) {
    if (strcasecmp(sbnc_account(), $_REQUEST['user']) == 0) {
		printf('%s',$lang_vlist['cantdeleteown']);
    } else {
	$result = explode(' ', sbnc_command('vdeluser ' . $_REQUEST['user']), 2);

	if ($result[0] == -1) {
    	    printf('%s %s', $lang_vlist['usernotdeleted'], $result[1]);
	} else {
    	    printf($lang_vlist['userdeleted'], htmlentities($_REQUEST['user']));
	}	
    }
  } else {
	printf(
	    $lang_vlist['deletedconfirmation'].'
	    <form method="POST" action="index.php">
	    <input type="hidden" name="p" value="vlist">
	    <input type="hidden" name="user" value="'.$_REQUEST['user'].'">
	    <input type="hidden" name="confirmation" value="true">
	    <input type="hidden" name="do" value="delete">
	    <input type="submit" name="Delete" value="%s">
	    </form>
	',$_REQUEST['user'], $lang_vlist['deletebutton']);
  }															    
  printf('</fieldset><br />');
}

printf('
<fieldset><legend>%s</legend>
<table>
<tr><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td></tr>
', $lang_vlist['userslegend'], $lang_vlist['user'], $lang_vlist['channels'], $lang_vlist['uptime'], $lang_vlist['client'], $lang_vlist['level'], $lang_vlist['suspended'], $lang_vlist['action']);

$users = explode(' ', sbnc_command('vgroupusers'));
$users2 = array();
$vadmins = array();
$vusers = array();
foreach ($users as $user) {
    if (sbnc_command('visadmin '. $user)) { array_push($vadmins, $user); }
    else { array_push($vusers, $user); }
}

foreach ($vadmins as $user) {
    array_push($users2, $user);
}
foreach ($vusers as $user) {
    array_push($users2, $user);
}

foreach ($users2 as $user) {
  echo '<tr>';
  echo '<td>' . $user . '</td>';

  $chans = sbnc_command('vchannels ' . $user);
  echo '<td>' . ($chans == '' ? 0 : count(explode(' ', $chans))) . '</td>';

  echo '<td>' . htmlentities(sbnc_command('vuptimehr ' . $user)) . '</td>';
  echo '<td>';
  $client = sbnc_command('vclient ' . $user);

  if ($client == "") { printf($lang_vlist['no']); }
  else { printf('%s (%s)',$lang_vlist['yes'], htmlentities($client)); }

  echo '</td><td>';
  $level = sbnc_command('visadmin '. $user);
  if ($level) { printf($lang_vlist['virtualadministrator']); }
  else { printf($lang_vlist['user']); }
  
  echo '</td><td>' . (sbnc_command('vsuspended ' . $user) ? $lang_vlist['yes'] : $lang_vlist['no']) . '</td>';

  printf('
    <td>
	<table><tr><td>
	<form method="post" action="index.php">
	<input type="hidden" name="p" value="vlist">
        <input type="hidden" name="user" value="'.$user.'">
        <select name="do">
            <option value="delete">%s</option>
	    <option value="resetpass">%s</option>
        </select>
        </td><td valign="top">
        <input type="submit" value="%s">
        </td></tr></table>
        </form>
  </td>', $lang_vlist['delete'], $lang_vlist['resetpass'], $lang_vlist['do']);

  printf('</tr>');
}


printf('
</table>
<br>
<form>
<input TYPE="button" onClick="parent.location=\'index.php?p=vlist&do=create\'" value="%s">
</form>
</fieldset>',$lang_vlist['createuserbutton']);

?>