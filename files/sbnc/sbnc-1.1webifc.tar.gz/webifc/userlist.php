<?php

/*******************************************************************************
 * shroudBNC - an object-oriented framework for IRC                            *
 * Copyright (C) 2005 Gunnar Beutner                                           *
 *                                                                             *
 * This program is free software; you can redistribute it and/or               *
 * modify it under the terms of the GNU General Public License                 *
 * as published by the Free Software Foundation; either version 2              *
 * of the License, or (at your option) any later version.                      *
 *                                                                             *
 * This program is distributed in the hope that it will be useful,             *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU General Public License           *
 * along with this program; if not, write to the Free Software                 *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. *
 *******************************************************************************/

include_once('sec.php');

sbnc_guard();
sbnc_guardadmin();

/* ==================== CREATE A USER ===================== */
if (isset($_REQUEST['create'])) {
    printf('
	<table width="100%%">
	<tr><td width="40%%">
	<fieldset><legend>%s</legend>
	<h2>%s</h2>
	<form method="post" action="index.php">
	<input type="hidden" name="p" value="userlist" />
	<input type="hidden" name="create2" value="" />
	<table width="100%%">
	    <tr><td width="50%%"><b>%s</b></td><td width="50%%"><b>%s</b></td></tr>
	    <tr><td>%s</td><td><input name="username" /></td></tr>
	    <tr><td>%s <div style="font-size: 7pt;">%s</div></td><td><input type="password" name="pass" /></td></tr>
	    <tr><td>%s</td><td><input name="server" /></td></tr>
	    <tr><td>%s</td><td><input name="port" /></td></tr>
	    <tr><td>%s <div style="font-size: 7pt;">%s</div></td><td><input name="ident" /></td></tr>
	</table>
	<br>
	<input type="submit" value="%s" />
	</form>
	</fieldset>
	</td><td width="60%%">&nbsp;</td></tr></table>',
	    $lang_ulist['users'], $lang_ulist['createuser'], $lang_ulist['description'], $lang_ulist['value'], $lang_ulist['username'], $lang_ulist['password'], $lang_ulist['emptyforrandompass'], $lang_ulist['server'], $lang_ulist['port'], $lang_ulist['ident'], $lang_ulist['emptyusernameident'], $lang_ulist['create']);
  return;
}


if (isset($_REQUEST['create2']) && isset($_REQUEST['username'])) {
  if (strlen($_REQUEST['pass']) > 0) { $newpass = $_REQUEST['pass']; }
  else { 
    $newpass = "";
    for($i=0;$i<8;$i++) {
        $num = rand(48,122);
	if (($num > 46 && $num < 58) || ($num > 64 && $num < 91) || ($num > 96 && $num < 123)) {
	 $newpass .= chr($num);
	} else {
	    $i--;
	}
    }
  }
  $users = explode(" ", sbnc_command('userlist'));
  if (in_array($_REQUEST['username'], $users)) {
    printf('<fieldset><legend>%s</legend>', $lang_ulist['usercreatinglegend']);
    printf('%s', $lang_ulist['failedcreateuser']);
  } else {
    $result = sbnc_command('adduser ' . $_REQUEST['username'] . ' ' . $newpass);
    printf('<fieldset><legend>%s</legend>', $lang_ulist['usercreatinglegend']);
    if ($result) {
	printf('%s', $lang_ulist['failedcreateuser']);
    } else {
	printf($lang_ulist['usercreated'], htmlentities($_REQUEST['username']), $newpass);
	if (strlen($_REQUEST['ident']) > 0) {
	  sbnc_command('setident '.$_REQUEST['username'].' '.$_REQUEST['ident']);
	}
	if (strlen($_REQUEST['server']) > 0) { 
	  sbnc_command('adm '.$_REQUEST['username'].' set server '.$_REQUEST['server']);               
	}	
	if (strlen($_REQUEST['port']) > 0) { 
	  sbnc_command('adm '.$_REQUEST['username'].' set port '.$_REQUEST['port']); 
	}
    }
  }
  echo '</fieldset><br />';
}
/* ==================== END OF CREATING ===================== */

/* ==================== JUMP A USER ===================== */

if (isset($_REQUEST['jump'])) {
  sbnc_command('adm '.$_REQUEST['user']. ' jump');
  printf('<fieldset><legend>%s</legend>%s</fieldset><br />', $lang_ulist['jump'], $lang_ulist['done']);
}

/* ==================== END OF JUMP ===================== */
/* ==================== KILL A CLIENT ===================== */
if (isset($_REQUEST['do']) && $_REQUEST['do'] == "kill") {
 if (isset($_REQUEST['reason2'])) {
   echo sbnc_command('bncuserkill '.$_REQUEST['user'].' '.$_REQUEST['reason']);
   printf('<fieldset><legend>%s</legend>', $lang_ulist['kill']);
   printf('%s %s.</fieldset><br />',$lang_ulist['successfullykilledclient'], $_REQUEST['user']);
 }
 else {
   printf('
      <fieldset><legend>%s '.$_REQUEST['user'].'</legend>
      <form method="post" action="index.php">
	   <input type="hidden" name="p" value="userlist" />
           <input type="hidden" name="user" value="'.$_REQUEST['user'].'" />
	   <input type="hidden" name="reason2" value="true" />
	   <input type="hidden" name="do" value="kill" />
	   <label>%s</label>
	   <input type="text" name="reason" />
	   <input type="submit" value="%s">
	  </form>
	  </fieldset>
	  <br />
	  ', $lang_ulist['usertokill'], $lang_ulist['reason'], $lang_ulist['kill']);
  }
}

/*==================== END OF KILLING CLIENT ===========================*/
/* ==================== KILL A BOUNCER ===================== */
if (isset($_REQUEST['do']) && $_REQUEST['do'] == "disconnect") {
 if (isset($_REQUEST['reason2'])) {
   echo sbnc_command('bncuserdisconnect '.$_REQUEST['user'].' '.$_REQUEST['reason']);
   printf('<fieldset><legend>%s</legend>',$lang_ulist['disconnect']);
   printf('%s %s.</fieldset><br />',$lang_ulist['successfullykilledserver'], $_REQUEST['user']);
 }
 else {
   printf('
      <fieldset><legend>%s '.$_REQUEST['user'].'</legend>
      <form method="post" action="index.php">
	   <input type="hidden" name="p" value="userlist" />
           <input type="hidden" name="user" value="'.$_REQUEST['user'].'" />
	   <input type="hidden" name="do" value="disconnect" />
	   <input type="hidden" name="reason2" value="true" />
	   <label>%s</label>
	   <input type="text" name="reason" />
	   <input type="submit" value="disconnect">
	  </form>
	  </fieldset>
	  <br />
	  ', $lang_ulist['usertodisconnect'], $lang_ulist['reason'], $lang_ulist['disconnect']);
  }
}

/* ==================== END OF KILL A BOUNCER ===================== */

/* ==================== SEND A MESSAGE ========================== */

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "sendmessage") {
  if (isset($_REQUEST['message'])) {
    echo sbnc_command('sendmessagetouser '.$_REQUEST['user'].' Message from Administrator: '.$_REQUEST['message']);
    printf('<fieldset><legend>%s</legend>', $lang_ulist['messagesendlegend']);
    printf($lang_ulist['messagesend'], $_REQUEST['user'], $_REQUEST['message']);
    printf('</fieldset><br />');
  } else {
    printf('<fieldset><legend>%s</legend>', $lang_ulist['sendmessage']);
    printf('<form method="POST" action="index.php">
	  <input type="hidden" name="p" value="userlist">
	  <input type="hidden" name="user" value="'.$_REQUEST['user'].'">
	  <input type="hidden" name="do" value="sendmessage">
	  <input size="50" name="message">
	  <input type="submit" value="%s" name="Send">
	  </form></fieldset><br />', $lang_ulist['send']);
    }
}

/* ================== CLEAR HOSTS ============================== */

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "clearhosts") {
    sbnc_command('clearhost '.$_REQUEST['user']);
    printf('<fieldset><legend>'.$lang_ulist['clearhostlegend'].'</legend>done.</fieldset><br />', $lang_ulist['user']);
}

/* ====================  LOG ===================== */
if (isset($_REQUEST['do']) && $_REQUEST['do'] == "log") {
 if (isset($_REQUEST['deletelog'])) {
   echo sbnc_command('adm '.$_REQUEST['user'].' eraselog');
   printf('<fieldset><legend>%s</legend>',$lang_ulist['logerasedlegend']);
   printf('%s %s</fieldset><br />', $lang_ulist['successfullyerasedlog'], $_REQUEST['user']);
 }
 else {
   printf('
      <fieldset><legend>%s %s</legend>', $lang_ulist['logof'], $_REQUEST['user']);
	  $lines = explode("\005", sbnc_command('adm '.$_REQUEST['user'].' log'));
	  $nol = 0;
	  foreach ($lines as $line) {
	   echo $line . "<br />";
	   $nol++;
	  }
	  if ($nol == 2) { printf($lang_ulist['emptylog']); }
	  printf('
    	    <form method="post" action="index.php">
		<input type="hidden" name="p" value="userlist" />
        	<input type="hidden" name="user" value="'.$_REQUEST['user'].'" />
		<input type="hidden" name="deletelog" value="true" />
		<input type="hidden" name="do" value="log" />');
	 if ($nol > 1) { printf('<input type="submit" value="%s">', $lang_ulist['delete']); }
	 printf('
	    </form>
	  </fieldset>
    	  <br />');
  }
}

/* ==================== END OF LOG ===================== */
/* ==================== CHANNELS OF USER ===================== */
function cmp ($a, $b) {
   return strcmp(strtolower($a), strtolower($b));
}
if (isset($_REQUEST['do']) && $_REQUEST['do'] == "channel") {
	if (sbnc_command('adm '.$_REQUEST['user'].' value hasserver')) {
		if (isset($_REQUEST['info'])) {
		    printf('<fieldset><legend>'.$lang_ulist['chaninfoabout'].'</legend>', htmlentities($_REQUEST['info']));
		    printf('<table width="100%%">');
		    printf('<tr><td width="20%%"><b>%s</b></td><td>%s</td></tr>', $lang_ulist['channel'], htmlentities($_REQUEST['info']));
		    printf('<tr><td><b>%s</b></td><td>%s</td></tr>', $lang_ulist['channelmodes'], htmlentities(sbnc_command('adm '.$_REQUEST['user'].' chanmode ' . $_REQUEST['info'])));
		    printf('<tr><td valign="top"><b>%s</b></td><td>%s</td></tr>', $lang_ulist['topic'], htmlentities(sbnc_command('adm '.$_REQUEST['user'].' topic ' . $_REQUEST['info'])));
		    printf('<tr><td valign="top"><b>%s</b></td><td>', $lang_ulist['users']);
		    $users = split(" ",htmlentities(sbnc_command('adm '.$_REQUEST['user'].' chanlist ' . $_REQUEST['info'])));
		    usort($users, "cmp");
		    foreach ($users as $user) {
			echo $user.'</br>';
		    }
		    echo '</table>';
		    echo '</fieldset>';
		    echo '<br />';
		}
		if (isset($_REQUEST['join'])) {
		    if (isset($_REQUEST['key']) && strlen($_REQUEST['key']) > 0) {
			sbnc_command('adm '.$_REQUEST['user']. ' raw JOIN '.$_REQUEST['join'].' '.$_REQUEST['key']);
		    } else {
			sbnc_command('adm '.$_REQUEST['user']. ' raw JOIN '.$_REQUEST['join']);
		    }
			printf('<fieldset><legend>%s</legend>',$lang_ulist['channeljoined']);
			printf($lang_ulist['successfullyjoinedchannel'].'</fieldset><br />', $_REQUEST['user'], $_REQUEST['join']);
		}
		if (isset($_REQUEST['part'])) {
			echo sbnc_command('adm '.$_REQUEST['user']. ' raw PART '.$_REQUEST['part']);
			printf('<fieldset><legend>%s</legend>',$lang_ulist['channelparted']);
			printf($lang_ulist['successfullypartedchannel'].'</fieldset><br />', $_REQUEST['user'], $_REQUEST['part']);
		}

		printf('<fieldset><legend>'.$lang_ulist['chaninfoabout'].'</legends>
				<form method="POST" action="index.php">
					<input type="hidden" name="p" value="userlist">
					<input type="hidden" name="do" value="channel">
					<input type="hidden" name="user" value="'.$_REQUEST['user'].'">
					<input name="join">
					<label>%s</label>
					<input style="width:70px;" name="key">
					<input type="submit" value="%s">
				</form>
		<table border="0" width="80%%"><tr><td width="40%%">%s</td><td width="10%%">%s</td><td width="40%%">%s</td><td>%s</td></tr>', $_REQUEST['user'], $lang_ulist['key'], $lang_ulist['join'], $lang_ulist['channel'], $lang_ulist['users'], $lang_ulist['modes'], $lang_ulist['command']);

		$chans = explode(' ', sbnc_command('adm '.$_REQUEST['user'].' channels'));
		usort($chans, "cmp");
		$total = 0;
		foreach ($chans as $chan) {
			if ($chan != "") {
				echo '<tr><td><a href="index.php?p=userlist&do=channel&user='.$_REQUEST['user'].'&info=' . urlencode($chan) . '">';
				echo $chan . '</a></td><td>';
				echo htmlentities(sbnc_command('adm '.$_REQUEST['user'].' usercount ' . $chan));
				printf('</td><td>' . htmlentities(sbnc_command('adm '.$_REQUEST['user'].' chanmode ' . $chan)) . '</td><td>
');
				printf('<form>
<input type="button" value="%s"', $lang_ulist['part']);
				echo 'onClick="parent.location=\'index.php?p=userlist&do=channel&user='.$_REQUEST['user'].'&part='.urlencode($chan).'\'">
';
				printf('</form>
</td></tr>');
				$total++;
			}
		}
		printf('</table><br>');
		printf('%s %s', $lang_ulist['totalnumberofchannels'], $total);
	} else {
	    printf('<fieldset><legend>%s</legend>', $lang_ulist['notconnectedlegend']);
		printf('%s', $lang_ulist['notconnected']);
		printf('</fieldset><br />');
	}
	printf('</fieldset><br />');
}	

/* ==================== EDIT A USER ===================== */

if (isset($_REQUEST['name']) && isset($_REQUEST['value'])) {
  $name = $_REQUEST['name'];
  $value = $_REQUEST['value'];
  if (isset($_REQUEST['lock'])) { $lock = $_REQUEST['lock']; }
  else { $lock = ""; }
  switch ($name) {
    case 'server':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." server"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." server"); }
      sbnc_command('adm '.$_REQUEST['user'].' set server ' . $value);
      break;
    case 'port':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." port"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." port"); }
      sbnc_command('adm '.$_REQUEST['user'].' set port ' . $value);
      break;
    case 'nick':
      sbnc_command('adm '.$_REQUEST['user'].' raw NICK '.$value);
      $nick = $value;
      break;
    case 'realname':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." realname"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." realname"); }
      sbnc_command('adm '.$_REQUEST['user'].' set realname ' . $value);
      break;
    case 'awaynick':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." awaynick"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." awaynick"); }
      sbnc_command('adm '.$_REQUEST['user'].' set awaynick ' . $value);
      break;
    case 'away':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." away"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." away"); }
      sbnc_command('adm '.$_REQUEST['user'].' set away ' . $value);
      break;
    case 'vhost':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." vhost"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." vhost"); }
      sbnc_command('adm '.$_REQUEST['user'].' set vhost ' . $value);
      break;
    case 'ident':
      sbnc_command('setident '.$_REQUEST['user'].' ' . $value);
      break;
    case 'awaymessage':
      if ($lock != "") { sbnc_command("locksetting ".$_REQUEST['user']." awaymessage"); }
      else { sbnc_command("unlocksetting ".$_REQUEST['user']." awaymessage"); }
      sbnc_command('adm '.$_REQUEST['user'].' set awaymessage '.$value);
      break;
    case 'password':
      sbnc_command('adm '.$_REQUEST['user'].' set password '.$value);
      printf('<fieldset><legend>%s</legend>New password set.</fieldset><br />', $lang_ulist['password']);
      if ($_REQUEST['user'] == $_SESSION['sbncusername']) {
        $_SESSION['sbncpass'] = $value;
	sbnc_relogin($_SESSION['sbncusername'],$_SESSION['sbncpass']);
      }
      break;
  }
}

if (isset($_REQUEST['edit'])) {
  $options = array(
	"Password" => "password",
	"Server" => "server",
	"Port" => "port",
	"Nick" => "nick",
	"Realname" => "realname",
	"Away-Nick" => "awaynick",
	"Away-Reason" => "away",
	"Away-message" => "awaymessage",
	"Vhost" => "vhost",
	"Ident" => "ident"
	);
	$lock = sbnc_command('hasplugin lock');
   printf('
		<fieldset><legend>'.$lang_ulist['settingsforuser'].'</legend>
		<table>', $_REQUEST['user']);
	if ($lock) {
		printf('<tr><td align="right"><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td></tr>
		', $lang_ulist['name'], $lang_ulist['value'], $lang_ulist['lock'], $lang_ulist['commit']);
	} else {
		printf('<tr><td align="right"><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td></tr>
		', $lang_ulist['name'], $lang_ulist['value'], $lang_ulist['commit']);
	}
   	foreach ($options as $option => $bnc) {
	  echo '
		<tr><td valign="top" align="right">'.$lang_ulist[$option].'</td><td valign="top">
		<form method="post" action="index.php">
		<input type="hidden" name="p" value="userlist" />
		<input type="hidden" name="name" value="'.$bnc.'" />
		<input type="hidden" name="user" value="'.$_REQUEST['user'].'">
		<input type="hidden" name="edit">
		<input size="40" name="value" ';
		if ($bnc == "ident") { echo 'maxlength="10" '; }
	  echo 'value="';
	  if ($bnc == "nick" && isset($nick)) { echo $nick; }
	  else if ($bnc == "awaymessage") { echo stripslashes(sbnc_command('adm '.$_REQUEST['user'].' tag awaymessage')); }
	  else if ($bnc != "password") { echo stripslashes(sbnc_command('adm '.$_REQUEST['user'].' value '.$bnc)); }
	  echo '" />';

	if ($lock) {
	  echo '</td><td valign="top">';
	  if ($bnc != "nick" && $bnc != "password" && $bnc != "ident") {
	    echo '<input type="checkbox" name="lock" ';
	    if (sbnc_command('adm '.$_REQUEST['user'].' lockedsetting '.$bnc) == 1) { echo 'checked'; }
	    if (sbnc_command('adm '.$_REQUEST['user'].' lockedsetting '.$bnc) == 2) { echo 'checked disabled'; }
	    echo '>';
	  } else { echo '&nbsp;'; }
	}
	  printf('
		</td><td valign="top">
		<input type="submit" value="%s">
		</form></td></tr>
		', $lang_ulist['set']);
	}
	$client = sbnc_command('adm '.$_REQUEST['user'].' value client');
	if ($client == "") { $client = $lang_ulist['notconnected']; }
	printf('<tr><td valign="top" align="right">Client</td><td>'.$client.'</td></tr>');
	printf('</table><br />');
	printf('	<form>
				<input TYPE="button" onClick="parent.location=\'index.php?p=userlist&edit=true&user='.$_REQUEST['user'].'&jump\'" value="%s">
			</form>
			', $lang_ulist['jump']);
	printf('</fieldset><br />');
}

/* ==================== END OF EDIT ===================== */

/* ==================== DELETE A USER ===================== */

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "delete") {
 if (isset($_REQUEST['confirmation'])) {
  if (strcasecmp(sbnc_account(), $_REQUEST['user']) == 0) {
    printf('%s', $lang_ulist['cantdeleteyourself']);
  } else {
    if (!sbnc_command('hasplugin virtual')) {
      $result = array(sbnc_command('deluser ' . $_REQUEST['user']), "User could not be deleted.");
    } else {
      $result = explode(' ', sbnc_command('vdeluser ' . $_REQUEST['user']), 2);
    }
    printf('<fieldset><legend>%s</legend>', $lang_ulist['userdeletedlegend']);
    if ($result[0] == -1) {
      echo $result[1];
    } else {
      printf($lang_ulist['userdeleted'], $_REQUEST['user']);
    }
    printf('</fieldset><br />');
  }
 } else {
    if (strcasecmp(sbnc_account(), $_REQUEST['user']) == 0) {
	printf('%s', $lang_ulist['cantdeleteyourself']);
    } else {
     printf('
      <fieldset><legend>'.$lang_ulist['usertodeletelegend'].'</legend>
      <form method="post" action="index.php">
	   <input type="hidden" name="p" value="userlist" />
           <input type="hidden" name="user" value="'.$_REQUEST['user'].'" />
	   <input type="hidden" name="do" value="delete" />
	   <input type="hidden" name="confirmation" value="true" />
	   <label>'.$lang_ulist['usertodelete'].'</label>
	   <input type="submit" value="%s">
	  </form>
	  </fieldset>
	  <br />
	  ', $_REQUEST['user'], $_REQUEST['user'], $lang_ulist['delete']);
    }
  }
}

/* ==================== END OF DELETE ===================== */

/* ==================== CHANGE A GROUP =================== */

if (isset($_REQUEST['do']) && $_REQUEST['do'] == "changegroup") {
    $guser = $_REQUEST['user'];
    $group = $_REQUEST['oldgroup'];
    if (isset($_REQUEST['newgroup'])) {
	if (sbnc_command('getvadmin '.$group) == $guser) {
	    printf('<fieldset><legend>%s</legend>
		    '.$lang_ulist['cannotchangegroup'].'
		  </fieldset><br />', $lang_ulist['changinggrouplegend'], $guser);
	} else {
	    if ($_REQUEST['newgroup'] == "none") {
		sbnc_command('vsetgroup '.$guser);
		printf('
		  <fieldset><legend>%s</legend>
		    '.$lang_ulist['removeduserfromgroup'].'
		  </fieldset><br />', $lang_ulist['changinggrouplegend'], $guser);
	    } else {
		sbnc_command('vsetgroup '.$guser.' '.$_REQUEST['newgroup']);
		printf('<fieldset><legend>%s</legend>
		    '.$lang_ulist['changedgroupofuser'].'
		  </fieldset><br />', $lang_ulist['changinggrouplegend'], $guser, $_REQUEST['newgroup']);
	    }
	}
    } else {
	if (sbnc_command('getvadmin '.$group) == $guser) {
	    printf('<fieldset><legend>%s</legend>'.$lang_ulist['cannotchangegroup'].'</fieldset><br />', $lang_ulist['changinggrouplegend'], $guser);
	} else {
	    printf('<fieldset><legend>%s</legend>', $lang_ulist['changinggrouplegend']);
	    printf($lang_ulist['changinggroupto'], $guser, $group);
	    $groups_str = sbnc_command('vgroups');
	    $groups = explode(' ', $groups_str);
	    if ($groups_str == "") {
		printf($lang_ulist['nogroupavailable']);
	    } else {
		echo '
		  <table><tr><td>&nbsp;</td></tr><tr><td> 
		  <form method="POST" action="index.php">
		    <input type="hidden" name="p" value="userlist">
		    <input type="hidden" name="do" value="changegroup">
		    <input type="hidden" name="user" value="'.$guser.'">
		    <input type="hidden" name="oldgroup" value="'.$group.'">
		    <select name="newgroup">
		    ';
		foreach ($groups as $group) {
		    echo '<option value="'.$group.'">'.$group.'</option>';
		}
		printf('<option value="none">&lt;%s&gt;</option>', $lang_ulist['none']);
		printf('</select></td><td valign="top">');
		printf('<input type="submit" name="set" value="%s"></form></td></tr></table>', $lang_ulist['set']);
	    }
	}
	printf('</fieldset><br />');
    }
}

/* ==================== END OF CHANGING GROUP =================== */
/* ==================== ADMIN A USER ===================== */

if (isset($_REQUEST['admin']) && isset($_REQUEST['was'])) {
  printf('<fieldset><legend>%s</legend>', $lang_ulist['administrator']);
  if (strcasecmp(sbnc_account(), $_REQUEST['admin']) == 0) {
    printf($lang_ulist['cantremoveownadmin']);
  } else {
    $result = sbnc_command(($_REQUEST['was'] == 'yes' ? 'unadmin' : 'admin') . ' ' . $_REQUEST['admin']);

    if ($result) {
      printf($lang_ulist['usernotchanged']); 
    } else {
      if ($_REQUEST['was'] == 'yes') {
	    printf($lang_ulist['usernownoadmin'], htmlentities($_REQUEST['admin']));
      } else {
	    printf($lang_ulist['usernowadmin'], htmlentities($_REQUEST['admin']));
      }
    }
  }
  printf('</fieldset></br>');
}

/* ==================== END OF ADMIN ===================== */

/* ==================== SUSPEND A USER ===================== */

if (isset($_REQUEST['suspend']) && isset($_REQUEST['was'])) {
  if (strcasecmp(sbnc_account(), $_REQUEST['suspend']) == 0) {
	printf('<fieldset><legend>%s</legend>', $lang_ulist['error']);
	printf($lang_ulist['cannotsuspendyourself'].'</fieldset><br />');
  } else {
     if ($_REQUEST['was'] == 'yes') {
       $result = sbnc_command('unsuspend '.$_REQUEST['suspend']);
       printf('<fieldset><legend>%s</legend>', $lang_ulist['suspension']);
       printf($lang_ulist['usernolongersuspended'].'</fieldset><br />', htmlentities($_REQUEST['suspend']));
     } else {
        if (isset($_REQUEST['reason2'])) {
	    $result = sbnc_command('suspend '.$_REQUEST['suspend'].' '.$_REQUEST['reason']);
        printf('<fieldset><legend>%s</legend>', $lang_ulist['suspension']);
        printf($lang_ulist['usernowsuspended'].'</fieldset><br />', htmlentities($_REQUEST['suspend']), htmlentities($_REQUEST['reason']));
	    printf('</fieldset><br />');
	} else {
        printf('<fieldset><legend>'.$lang_ulist['suspensionoflegend'].'</legend>', $_REQUEST['suspend']);
	    printf('	<form method="POST" action="index.php">
			    <input type="hidden" name="p" value="userlist">
			    <input type="hidden" name="suspend" value="'.$_REQUEST['suspend'].'">
			    <input type="hidden" name="was" value="'.$_REQUEST['was'].'">
			    <input type="hidden" name="reason2" value="true">
			    <label>%s</label>
			    <input name="reason">
			    <input type="submit" value="%s">
			</form></fieldset><br />', $lang_ulist['reason'], $lang_ulist['suspend']);
	   }
     }
  }
}    	
								  
/* ==================== END OF SUSPEND ===================== */
								  
/* ==================== MAIN ===================== */

if (isset($_REQUEST['group'])) {
  $lgroup = $_REQUEST['group'];
} else {
  $lgroup = "";
}

printf('<fieldset><legend>%s</legend>', $lang_ulist['users']);

if ($lgroup != "") {
  printf(' (%s ' . $lgroup . ')', $lang_ulist['group']);
}

printf('
<table width="100%%">
<tr><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td><td><b>%s</b></td>', $lang_ulist['user'], $lang_ulist['traffic'], $lang_ulist['channels'], $lang_ulist['uptime'], $lang_ulist['client'], $lang_ulist['level']);
  $vgroups = sbnc_command('hasplugin virtual');

  if ($vgroups) {
    printf('<td><b>%s</b></td>', $lang_ulist['group']);
  }
printf('<td><b>%s</b></td><td><b>%s</b></td></tr>', $lang_ulist['susp.'], $lang_ulist['action']);

$users = explode(' ', sbnc_command('userlist'));

function totaltraffic($user) {
  $traffic = explode(' ', sbnc_command('adm ' . $user . ' traffic'));

  return round(($traffic[0] + $traffic[1] + $traffic[2] + $traffic[3]) / 1024. / 1024., 2).'Mb';
}

$usersgroups = array();
foreach ($users as $user) {
    $group = sbnc_command('vgetgroup '.$user);
    if (isset($group) && $group == "") {
	if (!isset($usersgroups["none"])) { $usersgroups["none"] = $user; }
	else { $usersgroups["none"] .= ' '.$user; }
    } else {
	if (!isset($usersgroups[$group])) { $usersgroups[$group] = $user; }
	else { $usersgroups[$group] .= ' '.$user; }
    }
}
$usersgroupssort = array();
foreach ($usersgroups as $group => $groupusers) {
    $users = explode(' ', $groupusers);
    foreach ($users as $user) {
	if (isset($group) && $group == "none") {
	    if ($user != "") {
		if (sbnc_command('adm ' . $user . ' value admin')) {
		    if (isset($usersgroupssort["none"])) { $usersgroupssort["none"] = $user.' '.$usersgroupssort["none"]; }
		    else { $usersgroupssort["none"] = $user.' '; }
		} else {
		    if (isset($usersgroupssort["none"])) { $usersgroupssort["none"] = $usersgroupssort["none"].' '.$user; }
		    else { $usersgroupssort["none"] = $user.' '; }
		}
	    }
	} else {
	    if (sbnc_command('visadmin '.$user)) {
		if (isset($usersgroupssort[$group])) { $usersgroupssort[$group] = $user.' '.$usersgroupssort[$group]; }
		else { $usersgroupssort[$group] = $user.' '; }
	    } else {
		if (isset($usersgroupssort[$group])) { $usersgroupssort[$group] .= ' '.$user; }
		else { $usersgroupssort[$group] = $user; }
	    }
	}
    }
}

$userssort = array();
foreach ($usersgroupssort as $group => $user) {
    $users2 = explode(' ', $user);
    if ($group == "none") {
	foreach ($users2 as $u) {
	    if ($u != "") {
		array_push($userssort, $u);
	    }
	}
    }
}
foreach ($usersgroupssort as $group => $user) {
    $users2 = explode(' ', $user);
    if ($group != "none") {
	foreach ($users2 as $u) {
	    if ($u != "") {
		array_push($userssort, $u);
	    }
	}
    }
}
foreach ($userssort as $user) {
  if ($lgroup != "" && sbnc_command('vgetgroup ' . $user) != $lgroup)
    continue;
  echo '<tr>';
  echo '<td><a href="index.php?p=userlist&user='.$user.'&edit=true">' . $user . '</td>';
  echo '<td>' . totaltraffic($user) . '</td>';

  $chans = sbnc_command('adm ' . $user . ' channels');
  echo '<td>' . ($chans == '' ? 0 : count(explode(' ', $chans))) . '</td>';
  $uptime = sbnc_command('adm ' . $user . ' uptimehr');
  $uptime = str_replace('days','d',$uptime);
  $uptime = str_replace('hours','h',$uptime);
  $uptime = str_replace('minutes','m',$uptime);
  $uptime = str_replace('seconds','s',$uptime);
  echo '<td>' . htmlentities($uptime) . '</td>';
  echo '<td>';
  $client = sbnc_command('adm ' . $user . ' value client');
  
if ($client == "") { printf('%s', $lang_ulist['no']); }
  else { printf('%s', $lang_ulist['yes']); }
  echo '</td><td>';
  if (sbnc_command('adm ' . $user . ' value admin')) {
    printf('<a href="index.php?p=userlist&admin='.$user.'&was=yes">%s</a>', $lang_ulist['administrator']);
  } else if (sbnc_command('visadmin ' . $user)) {
    printf('%s', $lang_ulist['virtualadministrator']);
  } else {
    printf('<a href="index.php?p
=userlist&admin='.$user.'&was=no">%s</a>', $lang_ulist['user']);
  }
  echo '</td>';
  if (sbnc_command('hasplugin virtual')) {
    $group = sbnc_command('vgetgroup ' . $user);
	
    if ($group == "") { $group = $lang_ulist['none']; }
    $vgetadmin = 0;    
    echo '<td>';
    if (sbnc_command('vgetadmin '.$group) != $user) {
	$vgetadmin = 1;
	echo '<a href="index.php?p=userlist&user='.$user.'&oldgroup='.$group.'&do=changegroup">';
    }
    echo $group;
    if ($vgetadmin == 1) { echo '</a>'; }
    echo '</td>';
  }
  echo '</td><td><a href="index.php?p=userlist&suspend=' . $user . '&was=';
  if (sbnc_command('adm ' . $user . ' value lock')) { printf('yes">%s', $lang_ulist['yes']); } 
  else { printf('no">%s', $lang_ulist['no']); }
  echo '</a></td>';
  printf('
    <td>
      <table><tr><td>
      <form method="post" action="index.php">
	    <input type="hidden" name="p" value="userlist"> 
	    <input type="hidden" name="user" value="'.$user.'">
	    <select name="do">
		<option value="delete">%s</option>
		<option value="kill">%s</option>
		<option value="disconnect">%s</option>
		<option value="log">%s</option>
		<option value="channel">%s</option>
		<option value="sendmessage" selected>%s</option>
		<option value="clearhosts">%s</option>
	    </select>
	    </td><td valign="top">
	    <input type="submit" value="%s">
	    </td></tr></table>
      </form>
	</td>
	 ', $lang_ulist['delete'], $lang_ulist['killclient'], $lang_ulist['killbouncer'], $lang_ulist['log'], $lang_ulist['channels'], $lang_ulist['sendmessagebutton'], $lang_ulist['clearhost'], $lang_ulist['do']);

  echo '</tr>';
}

printf('
</table>
<br>
<form>
<input TYPE="button" onClick="parent.location=\'index.php?p=userlist&create\'" value="%s">
</form>
</fieldset>', $lang_ulist['createuserbutton']);

?>